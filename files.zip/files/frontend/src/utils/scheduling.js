import {
  DURATION_BY_BATHROOMS,
  DAY_START_MIN,
  DAY_END_MIN,
} from "../constants.js";

// ---------------------------------------------------------------------------
// Date/time helpers
// ---------------------------------------------------------------------------

export const uid = () =>
  Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);

export function pad2(n) {
  return String(n).padStart(2, "0");
}
export function toDateStr(d) {
  return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
}
export function timeToMin(t) {
  const [h, m] = t.split(":").map(Number);
  return h * 60 + m;
}
export function minToTime(m) {
  const h = Math.floor(m / 60);
  const mm = m % 60;
  return `${pad2(h)}:${pad2(mm)}`;
}
export function fmtTime12(value) {
  const [hours, minutes] = value.split(":").map(Number);
  const suffix = hours >= 12 ? "PM" : "AM";
  const hour12 = hours % 12 || 12;
  return `${hour12}:${pad2(minutes)} ${suffix}`;
}
export function addDays(dateStr, n) {
  const d = new Date(dateStr + "T00:00:00");
  d.setDate(d.getDate() + n);
  return toDateStr(d);
}
export function addMonths(dateStr, n) {
  const d = new Date(dateStr + "T00:00:00");
  d.setMonth(d.getMonth() + n);
  return toDateStr(d);
}
export function fmtDateHuman(dateStr) {
  const d = new Date(dateStr + "T00:00:00");
  return d.toLocaleDateString("en-IN", {
    weekday: "short",
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
}
export function fmtMoney(n) {
  return `\u20b9${Number(n || 0).toLocaleString("en-IN")}`;
}
export function norm(s) {
  return (s || "").toString().toLowerCase();
}
export function formatCustomerAddress(customer) {
  return [
    customer?.doorNumber,
    customer?.blockNumber,
    customer?.apartmentNumber,
    customer?.address,
    customer?.area,
  ]
    .filter(Boolean)
    .filter((value, index, values) => values.indexOf(value) === index)
    .join(", ") || "No address";
}

// ---------------------------------------------------------------------------
// Conflict-free scheduling
// ---------------------------------------------------------------------------

function occupiedWindow(
  booking,
  durationByBathrooms = DURATION_BY_BATHROOMS,
  bufferMinutes = 0,
) {
  const s = timeToMin(booking.startTime);
  if (booking.endTime) return [s, timeToMin(booking.endTime)];
  const dur = durationByBathrooms[booking.bathroomCount] || 60;
  return [s, s + dur + bufferMinutes];
}

// True if placing a job of this size at this date/time would overlap an
// existing booking (including the required buffer), or fall outside
// working hours.
export function hasConflict(
  dateStr,
  startTime,
  bathroomCount,
  bookings,
  excludeId,
  durationByBathrooms = DURATION_BY_BATHROOMS,
  enforceWorkingHours = true,
  bufferMinutes = 0,
) {
  const dur = durationByBathrooms[bathroomCount];
  const s = timeToMin(startTime);
  const e = s + dur + bufferMinutes;
  if (enforceWorkingHours && (s < DAY_START_MIN || s + dur > DAY_END_MIN)) return true;
  return bookings.some((b) => {
    if (b.id === excludeId) return false;
    if (b.date !== dateStr) return false;
    if (b.status === "cancelled") return false;
    if (!b.startTime) return false;
    const [os, oe] = occupiedWindow(b, durationByBathrooms, bufferMinutes);
    return s < oe && os < e;
  });
}

// All free start times on a given day for a job of this size.
export function findAvailableStarts(
  dateStr,
  bathroomCount,
  bookings,
  excludeId,
  durationByBathrooms = DURATION_BY_BATHROOMS,
  enforceWorkingHours = true,
  bufferMinutes = 0,
) {
  const dur = durationByBathrooms[bathroomCount];
  const starts = [];
  const latestStart = enforceWorkingHours ? DAY_END_MIN - dur : DAY_END_MIN;
  for (let t = DAY_START_MIN; t <= latestStart; t += 15) {
    const startTime = minToTime(t);
    if (!hasConflict(dateStr, startTime, bathroomCount, bookings, excludeId, durationByBathrooms, enforceWorkingHours, bufferMinutes))
      starts.push(startTime);
  }
  return starts;
}

// Never returns an overlapping slot: the exact desired time if it's free,
// otherwise the nearest free slot that day, otherwise null (meaning the
// day is fully booked and this visit needs manual placement).
export function pickSlot(
  dateStr,
  desiredTime,
  bathroomCount,
  bookings,
  excludeId,
  durationByBathrooms = DURATION_BY_BATHROOMS,
) {
  if (!hasConflict(dateStr, desiredTime, bathroomCount, bookings, excludeId, durationByBathrooms))
    return desiredTime;
  const starts = findAvailableStarts(
    dateStr,
    bathroomCount,
    bookings,
    excludeId,
    durationByBathrooms,
  );
  if (starts.length === 0) return null;
  const desiredMin = timeToMin(desiredTime);
  starts.sort(
    (a, b) =>
      Math.abs(timeToMin(a) - desiredMin) - Math.abs(timeToMin(b) - desiredMin),
  );
  return starts[0];
}

export function frequencyIntervalDays(frequency, configuredIntervalDays) {
  if (frequency === "weekly") return 7;
  if (frequency === "biweekly") return 14;
  return Number(configuredIntervalDays) > 0 ? Number(configuredIntervalDays) : null;
}

// Expands a subscription (start date + frequency + total weeks) into the
// list of visit dates.
export function generateOccurrenceDates(startDate, frequency, weeks, intervalDays) {
  if (frequency === "once") return [startDate];
  const databaseIntervalDays = frequencyIntervalDays(frequency, intervalDays);
  if (databaseIntervalDays > 0) {
    const visitCount = Math.max(
      1,
      Math.ceil((Number(weeks) * 7) / databaseIntervalDays),
    );
    return Array.from({ length: visitCount }, (_, index) =>
      addDays(startDate, index * databaseIntervalDays),
    );
  }
  if (frequency === "weekly") {
    const dates = [];
    for (let i = 0; i < weeks; i++) dates.push(addDays(startDate, i * 7));
    return dates;
  }
  if (frequency === "biweekly") {
    const dates = [];
    for (let i = 0; i < Math.max(1, Math.ceil(weeks / 2)); i++) dates.push(addDays(startDate, i * 14));
    return dates;
  }
  const count = Math.max(1, Math.round(weeks / 4));
  const dates = [];
  for (let i = 0; i < count; i++) dates.push(addMonths(startDate, i));
  return dates;
}

// ---------------------------------------------------------------------------
// WhatsApp deep links (no API key needed — opens WhatsApp with the message
// pre-filled; the person still taps Send themselves)
// ---------------------------------------------------------------------------

export function cleanPhone(p) {
  return (p || "").replace(/\D/g, "");
}
export function waLink(phone, message) {
  return `https://wa.me/${cleanPhone(phone)}?text=${encodeURIComponent(message)}`;
}

// ---------------------------------------------------------------------------
// Image resize for job-completion photos before they are sent to the API.
// ---------------------------------------------------------------------------

export function resizeImageFile(file, maxWidth = 480, quality = 0.6) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = reject;
    reader.onload = () => {
      const img = new Image();
      img.onerror = reject;
      img.onload = () => {
        const scale = Math.min(1, maxWidth / img.width);
        const canvas = document.createElement("canvas");
        canvas.width = img.width * scale;
        canvas.height = img.height * scale;
        canvas
          .getContext("2d")
          .drawImage(img, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL("image/jpeg", quality));
      };
      img.src = reader.result;
    };
    reader.readAsDataURL(file);
  });
}
