import React from "react";
import ReactDOM from "react-dom/client";
import CssBaseline from "@mui/material/CssBaseline";
import App from "./App.jsx";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    {/* CssBaseline resets browser defaults and applies the MUI theme background */}
    <CssBaseline />
    <App />
  </React.StrictMode>
);
