import { createTheme } from "@mui/material/styles";
import { BRAND } from "./constants.js";

// Called with "light" or "dark" — App.jsx holds the mode in state so the
// Sun/Moon toggle in the top bar can switch it at runtime.
export function buildTheme(mode) {
  const isDark = mode === "dark";
  return createTheme({
    palette: {
      mode,
      primary: { main: "#E26D4F" },
      secondary: { main: "#2D7A69" },
      success: { main: BRAND.green },
      background: {
        default: isDark ? "#111716" : "#F5F2ED",
        paper: isDark ? "#1A2421" : "#FFFEFC",
      },
      text: { primary: isDark ? "#F4F6F1" : "#202925", secondary: isDark ? "#AABAB0" : "#718079" },
      divider: isDark ? "rgba(219,236,225,0.12)" : "#E5E1D9",
    },
    shape: { borderRadius: 14 },
    typography: {
      fontFamily: "'Inter', 'Segoe UI', sans-serif",
      h1: { fontFamily: "'Poppins', sans-serif", fontWeight: 700 },
      h2: { fontFamily: "'Poppins', sans-serif", fontWeight: 700 },
      h3: { fontFamily: "'Poppins', sans-serif", fontWeight: 700 },
      h4: { fontFamily: "'Poppins', sans-serif", fontWeight: 700 },
      h5: { fontFamily: "'Poppins', sans-serif", fontWeight: 700 },
      h6: { fontFamily: "'Poppins', sans-serif", fontWeight: 700 },
      button: { textTransform: "none", fontWeight: 600 },
    },
    components: {
      MuiButton: {
        styleOverrides: { root: { borderRadius: 10, boxShadow: "none", minHeight: 40, paddingInline: 16, "&:hover": { boxShadow: "none" } } },
      },
      MuiPaper: {
        styleOverrides: { root: { backgroundImage: "none", borderColor: isDark ? "rgba(219,236,225,0.12)" : "#E5E1D9" } },
      },
      MuiAppBar: {
        styleOverrides: {
          root: {
            backgroundColor: isDark ? "rgba(26,36,33,0.94)" : "rgba(255,254,252,0.94)",
            color: isDark ? "#EDEFEE" : "#202925",
            backdropFilter: "blur(12px)",
          },
        },
      },
      MuiOutlinedInput: { styleOverrides: { root: { borderRadius: 10, backgroundColor: isDark ? "rgba(255,255,255,0.03)" : "#FBFAF7" } } },
      MuiChip: { styleOverrides: { root: { fontWeight: 600 } } },
    },
  });
}
