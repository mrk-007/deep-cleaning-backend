import { useMemo, useState } from "react";
import Box from "@mui/material/Box";
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import DialogActions from "@mui/material/DialogActions";
import Paper from "@mui/material/Paper";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import Stack from "@mui/material/Stack";
import Divider from "@mui/material/Divider";
import TextField from "@mui/material/TextField";
import MenuItem from "@mui/material/MenuItem";
import ScheduleTable from "./ScheduleTable.jsx";
import {
  timeToMin,
  toDateStr,
  fmtDateHuman,
  fmtTime12,
  minToTime,
  norm,
  formatCustomerAddress,
} from "../../utils/scheduling.js";

export default function BookingSchedule({
  bookings,
  customerById,
  goToCalendar,
  goToCustomerRegistration,
  durationByBathrooms,
}) {
  const [selectedSchedule, setSelectedSchedule] = useState(null);
  const [scheduleRange, setScheduleRange] = useState("today");
  const [areaSearch, setAreaSearch] = useState("");
  const today = toDateStr(new Date());

  const scheduledJobs = useMemo(() => {
    const todayDate = new Date(`${today}T00:00:00`);
    const weekStart = new Date(todayDate);
    weekStart.setDate(todayDate.getDate() - ((todayDate.getDay() + 6) % 7));
    const weekStartStr = toDateStr(weekStart);
    const monthStartStr = `${today.slice(0, 7)}-01`;
    const rangeStart =
      scheduleRange === "today"
        ? today
        : scheduleRange === "week"
          ? weekStartStr
          : monthStartStr;
    const rangeEnd =
      scheduleRange === "month"
        ? toDateStr(
            new Date(todayDate.getFullYear(), todayDate.getMonth() + 1, 0),
          )
        : scheduleRange === "week"
          ? toDateStr(
              new Date(
                weekStart.getFullYear(),
                weekStart.getMonth(),
                weekStart.getDate() + 6,
              ),
            )
          : today;
    const areaQuery = norm(areaSearch).trim();

    return bookings
      .filter((booking) => {
        const customer = customerById[booking.customerId];
        return (
          booking.date >= rangeStart &&
          booking.date <= rangeEnd &&
          booking.status !== "cancelled" &&
          booking.status !== "conflict" &&
          booking.startTime &&
          (!areaQuery || norm(customer?.area).includes(areaQuery))
        );
      })
      .sort(
        (a, b) =>
          a.date.localeCompare(b.date) ||
          timeToMin(a.startTime) - timeToMin(b.startTime),
      );
  }, [areaSearch, bookings, customerById, scheduleRange, today]);

  return (
    <>
      <Paper
        variant="outlined"
        sx={{ p: { xs: 2, sm: 2.5 }, overflow: "hidden" }}
      >
        {/* Table head */}
        <Box
          sx={{
            display: { xs: "block", md: "flex" },
            justifyContent: "space-between",
            alignItems: "center",
            mb: 2.5,
          }}
        >
          {/* The booking / Schedule */}
          <Box sx={{ mb: { xs: 1.5, md: 0 } }}>
            
            <Typography variant="h6" fontWeight={700}>
              {scheduleRange === "today"
                ? "Today's Cleaning Schedule"
                : scheduleRange === "week"
                  ? "This Week's Cleaning Schedule"
                  : "This Month's Cleaning Schedule"}
            </Typography>
            <Typography variant="caption" color="text.secondary">
              {scheduledJobs.length
                ? `${scheduledJobs.length} Scheduled Cleaning Visit${scheduledJobs.length > 1 ? "s" : ""}`
                : `No scheduled visits ${scheduleRange === "today" ? "today" : `this ${scheduleRange}`}`}
            </Typography>
          </Box>

          {/* Search, Filter and calender nav */}
          <Stack
            direction={{ xs: "column", sm: "row" }}
            spacing={{ xs: 2, sm: 1 }}
            alignItems={{ xs: "stretch", sm: "center" }}
          >
            <TextField
              size="small"
              label="Search area"
              placeholder="Enter area"
              value={areaSearch}
              onChange={(event) => setAreaSearch(event.target.value)}
              sx={{ minWidth: { sm: 190 } }}
              inputProps={{ "aria-label": "Search bookings by area" }}
            />
            <TextField
              select
              size="small"
              label="Show"
              value={scheduleRange}
              onChange={(event) => setScheduleRange(event.target.value)}
              sx={{ minWidth: { sm: 145 } }}
              inputProps={{ "aria-label": "Choose booking date range" }}
            >
              <MenuItem value="today">Today</MenuItem>
              <MenuItem value="week">This week</MenuItem>
              <MenuItem value="month">This month</MenuItem>
            </TextField>
            <Button
              variant="contained"
              onClick={goToCustomerRegistration}
              sx={{ whiteSpace: "nowrap" }}
            >
              Add customer
            </Button>
            {/* <Button size="small" onClick={goToCalendar}>
              Open calendar
            </Button> */}
          </Stack>
        </Box>
        
        {scheduledJobs.length === 0 ? (
          <Typography
            variant="body2"
            color="text.secondary"
            sx={{ py: 3, textAlign: "center" }}
          >
            No jobs match the selected area and date range.
          </Typography>
        ) : (
          <ScheduleTable
            jobs={scheduledJobs}
            customerById={customerById}
            durationByBathrooms={durationByBathrooms}
            onScheduleSelect={setSelectedSchedule}
          />
        )}
      </Paper>

      <Dialog
        open={!!selectedSchedule}
        onClose={() => setSelectedSchedule(null)}
        fullWidth
        maxWidth="sm"
      >
        <DialogTitle>Customer and booking details</DialogTitle>
        <DialogContent dividers>
          {selectedSchedule &&
            (() => {
              const customer = customerById[selectedSchedule.customerId];
              const duration =
                durationByBathrooms[selectedSchedule.bathroomCount] || 60;
              const start = selectedSchedule.startTime
                ? timeToMin(selectedSchedule.startTime) 
                : null;
              const fullAddress = formatCustomerAddress(customer);

              return (
                <Stack spacing={1.25}>
                  {/* Customer details */}
                  <Typography variant="h6" color="text.secondary">
                    Customer information
                  </Typography>
                  <Stack spacing={0.5}>
                    <Typography variant="body2">
                      <b>Name:</b> {customer?.name || "Unknown customer"}
                  </Typography>
                    <Typography variant="body2">
                      <b>Phone:</b> {customer?.phone || "Not provided"}
                    </Typography>
                    <Typography variant="body2">
                      <b>Address:</b> {fullAddress || "Not provided"}
                    </Typography>
                    <Typography variant="body2">
                      <b>Area:</b> {customer?.area || "Not provided"}
                    </Typography>
                    <Typography variant="body2">
                      <b>Pincode:</b> {customer?.pincode || "Not provided"}
                    </Typography>
                    <Typography variant="body2">
                      <b>City:</b> {customer?.city || "Not provided"}
                    </Typography>
                    <Typography variant="body2">
                      <b>Landmark:</b> {customer?.landmark || "Not provided"}
                    </Typography>
                  </Stack>
                  {/* Booking Details */}
                  <Divider sx={{ my: 0.5 }} />
                  <Typography variant="h6" color="text.secondary">
                    Booking information
                  </Typography>
                  <Stack spacing={0.5}>
                    <Typography variant="body2">
                      <b>Date:</b> {fmtDateHuman(selectedSchedule.date)}
                    </Typography>
                    <Typography variant="body2">
                      <b>Time:</b>{" "}
                      {start === null
                        ? "Not scheduled"
                        : `${fmtTime12(selectedSchedule.startTime)} - ${fmtTime12(minToTime(start + duration))}`}
                    </Typography>
                    <Typography variant="body2">
                      <b>Service:</b> {selectedSchedule.bathroomCount} bathroom
                      {selectedSchedule.bathroomCount > 1 ? "s" : ""}
                    </Typography>
                    <Typography variant="body2">
                      <b>Duration:</b> {duration} minutes
                    </Typography>
                    <Typography variant="body2">
                      <b>Frequency:</b>{" "}
                      {selectedSchedule.frequency || "One-time"}
                    </Typography>
                    {selectedSchedule.weeks && (
                      <Typography variant="body2">
                        <b>Subscription:</b> {selectedSchedule.weeks} weeks
                      </Typography>
                    )}
                    <Typography variant="body2">
                      <b>Status:</b> {selectedSchedule.status}
                    </Typography>
                  </Stack>
                </Stack>
              );
            })()}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setSelectedSchedule(null)}>Close</Button>
        </DialogActions>
      </Dialog>
    </>
  );
}
