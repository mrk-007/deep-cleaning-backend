import { useMemo, useState } from "react";
import {
  Box,
  Grid,
  Paper,
  Typography,
  Stack,
  Dialog,
  DialogTitle,
  DialogContent,
  IconButton,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TablePagination,
  TableRow,
  MenuItem,
  TextField,
} from "@mui/material";
import EventAvailableIcon from "@mui/icons-material/EventAvailable";
import EventBusyIcon from "@mui/icons-material/EventBusy";
import CloseIcon from "@mui/icons-material/Close";
import SpaceDashboardOutlinedIcon from "@mui/icons-material/SpaceDashboardOutlined";

import {
  fmtDateHuman,
  fmtTime12,
  toDateStr,
} from "../../utils/scheduling.js";

function SummaryDetailsTable({
  type,
  rows,
  page,
  rowsPerPage,
  onPageChange,
  onRowsPerPageChange,
}) {
  const columns =
    type === "today"
      ? ["Customer", "Phone", "Area", "Time", "Status"]
      : type === "plans"
        ? ["Customer", "Phone", "Area", "Visits", "Plan period"]
        : ["Customer", "Phone", "Area", "Ending date"];
  const visibleRows = rows.slice(
    page * rowsPerPage,
    page * rowsPerPage + rowsPerPage,
  );

  return (
    <>
      <TableContainer
        sx={{ border: 1, borderColor: "divider", borderRadius: 1 }}
      >
        <Table size="small">
          <TableHead>
            <TableRow sx={{ bgcolor: "action.hover" }}>
              {columns.map((column) => (
                <TableCell
                  key={column}
                  sx={{ fontWeight: 700, whiteSpace: "nowrap" }}
                >
                  {column}
                </TableCell>
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
            {visibleRows.map((row) => {
              const customer = row.customer;
              const values =
                type === "today"
                  ? [
                      customer?.name || "Unnamed customer",
                      customer?.phone || "Phone not provided",
                      customer?.area || "Area not provided",
                      row.startTime ? fmtTime12(row.startTime) : "Unscheduled",
                      row.status,
                    ]
                  : type === "plans"
                    ? [
                        customer?.name || "Unnamed customer",
                        customer?.phone || "Phone not provided",
                        customer?.area || "Area not provided",
                        `${row.visits} visits`,
                        `${fmtDateHuman(row.startDate)} to ${fmtDateHuman(row.endDate)}`,
                      ]
                    : [
                        customer?.name || "Unnamed customer",
                        customer?.phone || "Phone not provided",
                        customer?.area || "Area not provided",
                        fmtDateHuman(row.endDate),
                      ];
              return (
                <TableRow
                  key={row.id || `${row.customerId}-${row.endDate}`}
                  hover
                >
                  {values.map((value, index) => (
                    <TableCell
                      key={`${columns[index]}-${value}`}
                      sx={{ whiteSpace: index === 0 ? "nowrap" : "normal" }}
                    >
                      {value}
                    </TableCell>
                  ))}
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </TableContainer>
      <TablePagination
        component="div"
        count={rows.length}
        page={page}
        onPageChange={onPageChange}
        onRowsPerPageChange={onRowsPerPageChange}
        rowsPerPage={rowsPerPage}
        rowsPerPageOptions={[5, 10, 25]}
      />
    </>
  );
}

export default function SummaryCards({ bookings, customers }) {
  const today = toDateStr(new Date());
  const currentMonthIndex = new Date().getMonth();
  const monthNames = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ];
  const currentMonthName = monthNames[currentMonthIndex];
  const [activeDialog, setActiveDialog] = useState(null);
  const [dialogPage, setDialogPage] = useState(0);
  const [dialogRowsPerPage, setDialogRowsPerPage] = useState(5);
  const [endingMonth, setEndingMonth] = useState(String(currentMonthIndex));

  // Summary Card Hook
  const todayUpcomingCount = useMemo(
    () =>
      bookings.filter(
        (booking) => booking.date === today && booking.status !== "cancelled",
      ).length,
    [bookings, today],
  );

  const subscriptionCount = useMemo(
    () =>
      new Set(bookings.map((booking) => booking.subscriptionId).filter(Boolean))
        .size,
    [bookings],
  );

  const todayAppointments = useMemo(
    () =>
      bookings
        .filter(
          (booking) => booking.date === today && booking.status !== "cancelled",
        )
        .map((booking) => ({
          ...booking,
          customer: customers.find(
            (customer) => customer.id === booking.customerId,
          ),
        }))
        .sort((first, second) =>
          (first.startTime || "").localeCompare(second.startTime || ""),
        ),
    [bookings, customers, today],
  );

  const activePlans = useMemo(() => {
    const plans = new Map();
    bookings.forEach((booking) => {
      if (booking.status === "cancelled" || !booking.subscriptionId) return;
      const current = plans.get(booking.subscriptionId) || {
        customerId: booking.customerId,
        visits: 0,
        startDate: booking.date,
        endDate: booking.date,
      };
      current.visits += 1;
      if (booking.date < current.startDate) current.startDate = booking.date;
      if (booking.date > current.endDate) current.endDate = booking.date;
      plans.set(booking.subscriptionId, current);
    });
    return [...plans.values()].map((plan) => ({
      ...plan,
      customer: customers.find((customer) => customer.id === plan.customerId),
    }));
  }, [bookings, customers]);
  
  const allEndingSubscriptions = useMemo(() => {
    const subscriptions = new Map();

    bookings.forEach((booking) => {
      if (
        booking.status === "cancelled" ||
        !booking.subscriptionId ||
        !booking.date
      )
        return;
      const current = subscriptions.get(booking.subscriptionId) || {
        customerId: booking.customerId,
        endDate: booking.date,
      };
      if (booking.date > current.endDate) current.endDate = booking.date;
      subscriptions.set(booking.subscriptionId, current);
    });

    return [...subscriptions.values()]
      .map((subscription) => ({
        ...subscription,
        customer: customers.find(
          (customer) => customer.id === subscription.customerId,
        ),
      }))
      .sort((first, second) => first.endDate.localeCompare(second.endDate));
  }, [bookings, customers]);

  const endingSubscriptions = useMemo(() => {
    const todayDate = new Date(`${today}T00:00:00`);
    const endingLimit = new Date(todayDate);
    endingLimit.setDate(endingLimit.getDate() + 30);
    return allEndingSubscriptions.filter(({ endDate }) => {
      const date = new Date(`${endDate}T00:00:00`);
      return endingMonth
        ? date >= todayDate && date.getMonth() === Number(endingMonth)
        : date >= todayDate && date <= endingLimit;
    });
  }, [allEndingSubscriptions, endingMonth, today]);

  const currentMonthEndingSubscriptions = useMemo(() => {
    const todayDate = new Date(`${today}T00:00:00`);
    return allEndingSubscriptions.filter(({ endDate }) => {
      const date = new Date(`${endDate}T00:00:00`);
      return date >= todayDate && date.getMonth() === currentMonthIndex;
    });
  }, [allEndingSubscriptions, currentMonthIndex, today]);

  
  const cards = [
    {
      label: "Today's Service Appointments",
      value: todayUpcomingCount,
      key: "upcoming",
      icon: EventAvailableIcon,
      color: "secondary.main",
      onClick: () => {
        setDialogPage(0);
        setActiveDialog("today");
      },
    },
    {
      label: "Active Service Plans",
      value: subscriptionCount,
      key: "subscriptions",
      icon: EventAvailableIcon,
      color: "primary.main",
      onClick: () => {
        setDialogPage(0);
        setActiveDialog("plans");
      },
    },
    {
      label: `Subscriptions Ending Soon - ${currentMonthName}`,
      value: currentMonthEndingSubscriptions.length,
      key: "ending",
      icon: EventBusyIcon,
      color: "warning.main",
      onClick: () => {
        setDialogPage(0);
        setEndingMonth(String(currentMonthIndex));
        setActiveDialog("ending");
      },
    },
  ];

  return (
    <Box>
      <Stack direction="row" spacing={1.25} alignItems="center" sx={{ mb: 1 }}>
        <SpaceDashboardOutlinedIcon color="primary" />
        <Typography variant="h5" sx={{ fontWeight: 800, lineHeight: 1.1 }}>
          Dashboard
        </Typography>
      </Stack>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
        Manage customer bookings, cleaning schedules, and service completion
        status.
      </Typography>

      <Grid container spacing={2} sx={{ mb: 3 }}>
        {cards.map((card) => {
          const Icon = card.icon;
          return (
            <Grid
              size={{ xs: 12, sm: 4 }}
              key={card.label}
              sx={{ display: "flex" }}
            >
              <Paper
                variant="outlined"
                onClick={card.onClick}
                role={card.onClick ? "button" : undefined}
                tabIndex={card.onClick ? 0 : undefined}
                onKeyDown={
                  card.onClick
                    ? (event) => {
                        if (event.key === "Enter" || event.key === " ")
                          card.onClick();
                      }
                    : undefined
                }
                sx={{
                  p: { xs: 2, sm: 2.25 },
                  width: "100%",
                  minHeight: 142,
                  display: "flex",
                  flexDirection: "column",
                  justifyContent: "space-between",
                  transition: "border-color 160ms ease, box-shadow 160ms ease",
                  "&:hover": { boxShadow: 2 },
                  ...(card.onClick && { cursor: "pointer" }),
                }}
              >
                {/* Icon bg box */}
                <Box
                  sx={{
                    width: 32,
                    height: 32,
                    display: "grid",
                    placeItems: "center",
                    borderRadius: 2,
                    bgcolor: "action.hover",
                  }}
                >
                  <Icon sx={{ color: card.color }} fontSize="small" />
                </Box>
                <Typography
                  variant="h6"
                  sx={{
                    mt: 1,
                    whiteSpace: "nowrap",
                  }}
                >
                  {card.value}
                </Typography>
                <Typography
                  variant="caption"
                  color="text.secondary"
                  sx={{ lineHeight: 1.25 }}
                >
                  {card.label}
                </Typography>
              </Paper>
            </Grid>
          );
        })}
      </Grid>

      <Dialog
        open={Boolean(activeDialog)}
        onClose={() => {
          setActiveDialog(null);
          setEndingMonth(String(currentMonthIndex));
          setDialogPage(0);
        }}
        disableEscapeKeyDown
        fullWidth
        maxWidth="md"
      >
        <DialogTitle
          sx={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
          }}
        >
          {activeDialog === "today"
            ? "Today's service appointments"
            : activeDialog === "plans"
              ? "Active service plans"
              : `Subscriptions ending soon - ${
                  endingMonth === ""
                    ? "Next 30 days"
                    : monthNames[Number(endingMonth)]
                }`}
          <IconButton
            aria-label="Close dashboard details"
            onClick={() => setActiveDialog(null)}
          >
            <CloseIcon />
          </IconButton>
        </DialogTitle>
        <DialogContent dividers sx={{ overflowX: "auto" }}>
          {activeDialog === "ending" && (
            <TextField
              select
              size="small"
              label="Ending month"
              value={endingMonth}
              onChange={(event) => {
                setEndingMonth(event.target.value);
                setDialogPage(0);
              }}
              sx={{ mb: 2, minWidth: 190 }}
            >
                <MenuItem value="">Next 30 days</MenuItem>
                {monthNames.map((month, index) => (
                <MenuItem key={month} value={index}>
                  {month}
                </MenuItem>
              ))}
            </TextField>
          )}
          {(activeDialog === "today"
            ? todayAppointments
            : activeDialog === "plans"
              ? activePlans
              : endingSubscriptions
          ).length ? (
            <SummaryDetailsTable
              type={activeDialog}
              rows={
                activeDialog === "today"
                  ? todayAppointments
                  : activeDialog === "plans"
                    ? activePlans
                    : endingSubscriptions
              }
              page={dialogPage}
              rowsPerPage={dialogRowsPerPage}
              onPageChange={(_, nextPage) => setDialogPage(nextPage)}
              onRowsPerPageChange={(event) => {
                setDialogRowsPerPage(Number(event.target.value));
                setDialogPage(0);
              }}
            />
          ) : (
            <Typography color="text.secondary">
              {activeDialog === "today"
                ? "No service appointments today."
                : activeDialog === "plans"
                  ? "No active service plans."
                  : "No subscriptions are ending in the next 30 days."}
            </Typography>
          )}
        </DialogContent>
      </Dialog>
    </Box>
  );
}
