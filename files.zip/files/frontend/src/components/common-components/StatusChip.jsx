import Chip from "@mui/material/Chip";

const CONFIG = {
  scheduled: {
    label: "Scheduled",
    sx: {
      color: "#B47C24",
      borderColor: "#B47C24",
      bgcolor: "rgba(180, 124, 36, 0.12)",
    },
  },
  conflict: { label: "Needs attention", color: "error" },
  unscheduled: { label: "Unscheduled", color: "error" },
  cancelled: { label: "Cancelled", color: "default" },
  completed: {
    label: "Completed",
    sx: {
      color: "#2D7A69",
      borderColor: "#2D7A69",
      bgcolor: "rgba(45, 122, 105, 0.12)",
    },
  },
};

export default function StatusChip({ status }) {
  const cfg = CONFIG[status] || { label: status, color: "default", sx: {} };
  return <Chip size="small" label={cfg.label} color={cfg.color} variant="outlined" sx={cfg.sx} />;
}
