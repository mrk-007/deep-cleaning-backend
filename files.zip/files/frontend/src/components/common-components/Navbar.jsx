import { useState } from "react";
import Box from "@mui/material/Box";
import AppBar from "@mui/material/AppBar";
import Toolbar from "@mui/material/Toolbar";
import Drawer from "@mui/material/Drawer";
import Divider from "@mui/material/Divider";
import List from "@mui/material/List";
import ListItemButton from "@mui/material/ListItemButton";
import ListItemIcon from "@mui/material/ListItemIcon";
import ListItemText from "@mui/material/ListItemText";
import IconButton from "@mui/material/IconButton";
import Typography from "@mui/material/Typography";
import Avatar from "@mui/material/Avatar";
import Stack from "@mui/material/Stack";
import Tooltip from "@mui/material/Tooltip";
import MenuIcon from "@mui/icons-material/Menu";
import DashboardIcon from "@mui/icons-material/SpaceDashboard";
import CalendarIcon from "@mui/icons-material/CalendarMonth";
import AddIcon from "@mui/icons-material/Add";
import SettingsIcon from "@mui/icons-material/Settings";
import PeopleIcon from "@mui/icons-material/People";
import ReceiptIcon from "@mui/icons-material/Receipt";
import LogoutIcon from "@mui/icons-material/Logout";
import jollyLogo from "../../assets/logo/Jollydark.png";

const DRAWER_WIDTH = 260;

const NAV_ITEMS = [
  { id: "dashboard", label: "Dashboard", icon: DashboardIcon },
  { id: "calendar", label: "Service Schedule", icon: CalendarIcon },
  { id: "new-booking", label: "Service Booking", icon: AddIcon },
  { id: "customers", label: "Customers Details", icon: PeopleIcon },
  { id: "invoices", label: "Invoices", icon: ReceiptIcon },
  { id: "settings", label: "Settings", icon: SettingsIcon },
];

export default function Navbar({
  view,
  setView,
  currentUser,
  onLogout,
  onNavigate,
  customerView = "details",
  onCustomerViewChange,
  children,
}) {
  const [mobileOpen, setMobileOpen] = useState(false);

  const navigate = (id) => {
    if (id === "customers") onCustomerViewChange?.("details");
    onNavigate ? onNavigate(id) : setView(id);
    setMobileOpen(false);
  };

  const drawerContent = (
    <Box
      sx={{
        position: "relative",
        height: "100%",
        display: "flex",
        flexDirection: "column",
        bgcolor: "#141414",
        color: "#fff",
        overflowY: "auto",
        scrollbarWidth: "none",
        "&::-webkit-scrollbar": { display: "none" },
      }}
    >
      <Box
        sx={{
          px: 3,
          py: 3,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          position: "sticky",
          top: 0,
          bgcolor: "#141414",
          borderBottom: 1,
          borderColor: "rgba(255,255,255,0.1)",
          zIndex: 2,
        }}
      >
        <Box
          component="img"
          src={jollyLogo}
          alt="Jolly Home Needs"
          sx={{ display: "block", width: 168, height: "auto" }}
        />
      </Box>
      <Divider sx={{ borderColor: "rgba(255,255,255,0.08)" }} />
      <List sx={{ flex: 1, px: 1.5, py: 1.5 }}>
        {NAV_ITEMS.map((item) => {
          const Icon = item.icon;
          const active = view === item.id;
          return (
            <ListItemButton
              key={item.id}
              selected={active}
              onClick={() => navigate(item.id)}
              sx={{
                borderRadius: 1,
                mb: 0.5,
                color: active ? "#4CD3B4" : "rgba(255,255,255,0.65)",
                "& .MuiListItemIcon-root": {
                  color: "inherit",
                  minWidth: 38,
                },
                "&.Mui-selected": {
                  bgcolor: "rgba(23,138,114,0.22)",
                  color: "#4CD3B4",
                },
                "&.Mui-selected:hover": { bgcolor: "rgba(23,138,114,0.28)" },
                "&:hover": { bgcolor: "rgba(255,255,255,0.06)" },
              }}
            >
              <ListItemIcon sx={{ color: "inherit", minWidth: 36 }}>
                <Icon fontSize="small" />
              </ListItemIcon>
              <ListItemText primary={item.label} />
            </ListItemButton>
          );
        })}
      </List>
    </Box>
  );

  return (
    <Box sx={{ display: "flex", minHeight: "100vh" }}>
      {/* Desktop: permanent drawer */}
      <Drawer
        variant="permanent"
        sx={{
          display: { xs: "none", md: "block" },
          width: DRAWER_WIDTH,
          flexShrink: 0,
          "& .MuiDrawer-paper": {
            width: DRAWER_WIDTH,
            boxSizing: "border-box",
            border: "none",
          },
        }}
        open
      >
        {drawerContent}
      </Drawer>

      {/* Mobile: temporary slide-in drawer */}
      <Drawer
        variant="temporary"
        open={mobileOpen}
        onClose={() => setMobileOpen(false)}
        ModalProps={{ keepMounted: true }}
        sx={{
          display: { xs: "block", md: "none" },
          "& .MuiDrawer-paper": {
            width: 260,
            boxSizing: "border-box",
            border: "none",
          },
        }}
      >
        {drawerContent}
      </Drawer>

      <Box
        sx={{
          flexGrow: 1,
          minWidth: 0,
          display: "flex",
          flexDirection: "column",
        }}
      >
        <AppBar
          position="sticky"
          elevation={0}
          sx={{ borderBottom: 1, borderColor: "divider" }}
        >
          <Toolbar sx={{ gap: 1 }}>
            <IconButton
              edge="start"
              onClick={() => setMobileOpen(true)}
              sx={{ display: { md: "none" } }}
            >
              <MenuIcon />
            </IconButton>
            <Box sx={{ display: "none" }}>
              <Box
                component="img"
                src={jollyLogo}
                alt="Jolly Home Needs"
                sx={{ display: "block", width: 88, height: "auto" }}
              />
            </Box>
            <Typography
              variant="h6"
              color="text.secondary"
              sx={{ display: "block", flexGrow: 1 }}
            >
              <Box component="span" sx={{ display: { xs: "inline", md: "none" } }}>
                MKPL
              </Box>
              <Box component="span" sx={{ display: { xs: "none", md: "inline" } }}>
                MEENAKOUSALYA PRIVATE LIMITED
              </Box>
            </Typography>
            <Box sx={{ flexGrow: 1, display: { sm: "none" } }} />

            <Stack
              direction="row"
              spacing={1}
              sx={{
                display: { xs: "none", sm: "flex" },
                pl: 1,
                borderLeft: 1,
                borderColor: "divider",
              }}
            >
              <Avatar sx={{ width: 28, height: 28, fontSize: 13 }}>
                {currentUser.name?.[0]?.toUpperCase()}
              </Avatar>
              <Box>
                <Typography
                  variant="caption"
                  sx={{ display: "block", lineHeight: 1.2, fontWeight: 600 }}
                >
                  {currentUser.name}
                </Typography>
                <Typography
                  variant="caption"
                  color="text.secondary"
                  sx={{ display: "block", lineHeight: 1.2 }}
                >
                  {currentUser.role === "superadmin" ? "Super admin" : "Admin"}
                </Typography>
              </Box>
            </Stack>

            <Tooltip title="Log out">
              <IconButton onClick={onLogout}>
                <LogoutIcon fontSize="small" />
              </IconButton>
            </Tooltip>
          </Toolbar>
        </AppBar>

        <Box
          component="main"
          sx={{
            flex: 1,
            p: { xs: 2, sm: 3 },
            maxWidth: 1200,
            width: "100%",
            mx: "auto",
          }}
        >
          {children}
        </Box>
      </Box>
    </Box>
  );
}
