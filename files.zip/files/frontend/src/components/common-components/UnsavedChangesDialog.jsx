import ConfirmDialog from "./ConfirmDialog.jsx";

export default function UnsavedChangesDialog({ open, onDiscard, onCancel }) {
  return (
    <ConfirmDialog
      open={open}
      title="Unsaved changes"
      message="Your recent updates have not been saved. Are you sure you want to discard them and continue?"
      confirmLabel="Discard"
      onConfirm={onDiscard}
      onClose={onCancel}
    />
  );
}