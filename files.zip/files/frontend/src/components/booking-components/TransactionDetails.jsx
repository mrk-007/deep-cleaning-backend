import Box from "@mui/material/Box";
import Grid from "@mui/material/Grid";
import MenuItem from "@mui/material/MenuItem";
import TextField from "@mui/material/TextField";
import Typography from "@mui/material/Typography";

export default function TransactionDetails({
  paymentMode,
  setPaymentMode,
  paymentOptions,
  accountOptions,
  paymentAmount,
  setPaymentAmount,
  bankType,
  setBankType,
  transactionId,
  setTransactionId,
}) {
  const requiresBankDetails = paymentMode && paymentMode !== "cash";

  const handlePaymentModeChange = (event) => {
    const nextPaymentMode = event.target.value;
    setPaymentMode(nextPaymentMode);
    if (nextPaymentMode === "cash") {
      setBankType("");
    }
  };

  return (
    <Box sx={{ mb: 2 }}>
      <Typography variant="subtitle2" sx={{ mb: 1.25, fontSize: 17 }}>
        Transaction Details
      </Typography>
      <Grid container spacing={2}>
        <Grid size={{ xs: 12, sm: 4 }}>
          <TextField
            select
            fullWidth
            size="small"
            label="Mode of payment"
            value={paymentMode}
            onChange={handlePaymentModeChange}
          >
            {paymentOptions.map((paymentOption) => (
              <MenuItem key={paymentOption.id} value={paymentOption.value}>
                {paymentOption.label}
              </MenuItem>
            ))}
          </TextField>
        </Grid>
        <Grid size={{ xs: 12, sm: 4 }}>
          <TextField
            fullWidth
            size="small"
            label="Payment amount"
            value={paymentAmount}
            onChange={(e) =>
              setPaymentAmount(e.target.value.replace(/\D/g, ""))
            }
            inputProps={{ inputMode: "numeric" }}
          />
        </Grid>
        <Grid size={{ xs: 12, sm: 4 }}>
          <TextField
            fullWidth
            size="small"
            label="Transaction ID"
            value={transactionId}
            onChange={(e) => setTransactionId(e.target.value)}
          />
        </Grid>
      </Grid>

      {requiresBankDetails && (
        <>
          <Typography variant="subtitle2" sx={{ mt: 2.5, mb: 1.25, fontSize: 17 }}>
            Receiver Bank Details
          </Typography>
          <Grid container spacing={2}>
            <Grid size={{ xs: 12, sm: 4 }}>
              <TextField
                select
                fullWidth
                size="small"
                label="Bank type"
                value={bankType}
                onChange={(e) => setBankType(e.target.value)}
              >
                {accountOptions.map((account) => (
                  <MenuItem key={account.id} value={account.id}>
                    {account.label}
                  </MenuItem>
                ))}
              </TextField>
            </Grid>
          </Grid>
        </>
      )}
    </Box>
  );
}
