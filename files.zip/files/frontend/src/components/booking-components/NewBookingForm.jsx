import { useEffect, useMemo, useRef, useState } from "react";
import {
  Autocomplete,
  Box,
  Button,
  CircularProgress,
  Grid,
  MenuItem,
  Stack,
  TextField,
  Typography,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Paper,
  Step,
  StepLabel,
  Stepper,
} from "@mui/material";
import CheckIcon from "@mui/icons-material/Check";
import WarningAmberIcon from "@mui/icons-material/WarningAmber";
import {
  hasConflict,
  findAvailableStarts,
  generateOccurrenceDates,
  fmtMoney,
  fmtTime12,
} from "../../utils/scheduling.js";
import TransactionDetails from "./TransactionDetails.jsx";

const parseTimeGapToDays = (timeGap) => {
  if (timeGap === null || timeGap === undefined || timeGap === "") return null;
  const normalized = String(timeGap).trim();
  if (!normalized) return null;
  const directNumber = Number(normalized);
  if (Number.isInteger(directNumber) && directNumber > 0) return directNumber;
  const match = normalized.match(/^(\d+)\s*(?:day|days)?$/i);
  if (!match) return null;
  const intervalDays = Number(match[1]);
  return intervalDays > 0 ? intervalDays : null;
};

export default function NewBookingForm({
  customers,
  bookings,
  pricing,
  onSubmit,
  preferredCustomerId,
  durationByBathrooms,
  frequencyOptions,
  subscriptionOptions,
  timeSlots,
  paymentOptions,
  paymentMaster,
  accountOptions,
  onDirtyChange,
}) {
  const [availableCustomers, setAvailableCustomers] = useState(customers);
  const [customerId, setCustomerId] = useState("");
  const [bathroomCount, setBathroomCount] = useState("");
  const [frequency, setFrequency] = useState("");
  const [weeks, setWeeks] = useState("");
  const [startDate, setStartDate] = useState("");
  const [startTime, setStartTime] = useState("");
  const [paymentMode, setPaymentMode] = useState("");
  const [paymentAmount, setPaymentAmount] = useState("");
  const [bankType, setBankType] = useState("");
  const [transactionId, setTransactionId] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [reviewOpen, setReviewOpen] = useState(false);
  const [finalReviewOpen, setFinalReviewOpen] = useState(false);
  const [bookingStep, setBookingStep] = useState(1);
  const submittingRef = useRef(false);

  const selectedCustomer =
    availableCustomers.find((customer) => customer.id === customerId) || null;
  const selectedFrequency = frequencyOptions.find(
    (option) => option.value === frequency,
  );
  const compatibleSubscriptions = useMemo(() => {
    if (!selectedFrequency?.intervalDays) return subscriptionOptions;

    const frequencyIntervalDays = Number(selectedFrequency.intervalDays);
    if (!Number.isInteger(frequencyIntervalDays) || frequencyIntervalDays <= 0) {
      return subscriptionOptions;
    }

    const filteredSubscriptions = subscriptionOptions.filter((subscription) => {
      const subscriptionCadenceDays = parseTimeGapToDays(subscription.timeGap);
      if (subscriptionCadenceDays === null) return true;
      return subscriptionCadenceDays === frequencyIntervalDays;
    });

    return filteredSubscriptions.length > 0
      ? filteredSubscriptions
      : subscriptionOptions;
  }, [selectedFrequency, subscriptionOptions]);
  const selectedSubscription = compatibleSubscriptions.find(
    (option) => option.weeks === Number(weeks),
  );
  const selectedPayment = paymentOptions.find(
    (option) => option.value === paymentMode,
  );
  const selectedAccount = accountOptions.find(
    (option) => option.id === bankType,
  );

  const databaseStartTimes = useMemo(() => {
    const generatedTimes = new Set();

    const toMinutes = (time) => {
      const match = String(time || "")
        .trim()
        .toUpperCase()
        .match(/^(\d{1,2}):(\d{2})\s*(AM|PM)?$/);
      if (!match) return null;

      let hours = Number(match[1]);
      const minutes = Number(match[2]);
      if (match[3] === "PM" && hours !== 12) hours += 12;
      if (match[3] === "AM" && hours === 12) hours = 0;
      return hours * 60 + minutes;
    };

    const toTime = (minutes) =>
      `${String(Math.floor(minutes / 60)).padStart(2, "0")}:${String(
        minutes % 60,
      ).padStart(2, "0")}`;

    timeSlots.forEach((slot) => {
      const startMinutes = toMinutes(slot.startTime);
      const endMinutes = toMinutes(slot.endTime);
      const bufferMinutes = Number(slot.bufferTime) || 0;
      const serviceDuration = Number(durationByBathrooms[bathroomCount]) || 0;
      const totalSlotDuration = serviceDuration + bufferMinutes;
      if (
        startMinutes === null ||
        endMinutes === null ||
        totalSlotDuration <= 0
      ) {
        return;
      }

      for (
        let currentMinutes = startMinutes;
        currentMinutes + totalSlotDuration <= endMinutes;
        currentMinutes += totalSlotDuration
      ) {
        generatedTimes.add(toTime(currentMinutes));
      }
    });

    return [...generatedTimes].sort();
  }, [bathroomCount, durationByBathrooms, timeSlots]);

  useEffect(() => {
    setAvailableCustomers((current) => {
      const merged = [...customers, ...current];
      return merged.filter(
        (customer, index, list) =>
          list.findIndex((item) => item.id === customer.id) === index,
      );
    });
  }, [customers]);

  useEffect(() => {
    if (
      preferredCustomerId &&
      customers.some((customer) => customer.id === preferredCustomerId)
    ) {
      setCustomerId(preferredCustomerId);
    }
  }, [preferredCustomerId, customers]);

  const availableStarts = useMemo(() => {
    if (!startDate || !bathroomCount) return [];
    const toMinutes = (time) => {
      const match = String(time || "")
        .trim()
        .toUpperCase()
        .match(/^(\d{1,2}):(\d{2})\s*(AM|PM)?$/);
      if (!match) return null;

      let hours = Number(match[1]);
      if (match[3] === "PM" && hours !== 12) hours += 12;
      if (match[3] === "AM" && hours === 12) hours = 0;
      return hours * 60 + Number(match[2]);
    };

    if (databaseStartTimes.length) {
      return databaseStartTimes.filter(
        (start) => {
          const selectedSlot = timeSlots.find((slot) => {
            const slotStart = toMinutes(slot.startTime);
            const slotEnd = toMinutes(slot.endTime);
            const selectedStart = toMinutes(start);
            return (
              selectedStart !== null &&
              slotStart !== null &&
              slotEnd !== null &&
              selectedStart >= slotStart &&
              selectedStart <= slotEnd
            );
          });
          const bufferMinutes = Number(selectedSlot?.bufferTime) || 0;

          return !hasConflict(
            startDate,
            start,
            bathroomCount,
            bookings,
            null,
            durationByBathrooms,
            false,
            bufferMinutes,
          );
        },
      );
    }
    const conflictFreeStarts = findAvailableStarts(
      startDate,
      bathroomCount,
      bookings,
      null,
      durationByBathrooms,
      false,
    );
    return timeSlots.length
      ? conflictFreeStarts.filter((start) => databaseStartTimes.includes(start))
      : conflictFreeStarts;
  }, [
    startDate,
    bathroomCount,
    bookings,
    durationByBathrooms,
    databaseStartTimes,
  ]);

  useEffect(() => {
    setStartTime((currentStartTime) =>
      availableStarts.includes(currentStartTime)
        ? currentStartTime
        : availableStarts[0] || "",
    );
  }, [availableStarts]);

  useEffect(() => {
    if (frequency === "once") {
      setWeeks("");
      return;
    }
    if (weeks && !compatibleSubscriptions.some((option) => option.weeks === Number(weeks))) {
      setWeeks("");
    }
  }, [frequency, weeks, compatibleSubscriptions]);

  const occurrences =
    startDate && frequency
      ? generateOccurrenceDates(
          startDate,
          frequency,
          weeks,
          selectedFrequency?.intervalDays,
        )
      : [];
  const estimatedVisitCount = selectedSubscription?.totalServiceVisits || occurrences.length;
  const baseAmount = (pricing[bathroomCount] || 0) * estimatedVisitCount;
  const appliedPaymentMaster = paymentMaster || {
    discountRate: 50,
    cgstRate: 9,
    sgstRate: 9,
  };
  const discountAmount =
    (baseAmount * Number(appliedPaymentMaster.discountRate || 0)) / 100;
  const taxableAmount = baseAmount - discountAmount;
  const cgstAmount =
    (taxableAmount * Number(appliedPaymentMaster.cgstRate || 0)) / 100;
  const sgstAmount =
    (taxableAmount * Number(appliedPaymentMaster.sgstRate || 0)) / 100;
  const totalValue = taxableAmount + cgstAmount + sgstAmount;
  const bookingDetailsComplete =
    !!customerId &&
    !!bathroomCount &&
    !!frequency &&
    (frequency === "once" || !!weeks) &&
    !!startDate &&
    !!startTime;
  const transactionDetailsComplete =
    !!paymentMode && !!paymentAmount && !!transactionId.trim();
  const isDirty = Boolean(
    customerId ||
    bathroomCount ||
    frequency ||
    weeks ||
    startDate ||
    startTime ||
    paymentMode ||
    paymentAmount ||
    bankType ||
    transactionId.trim(),
  );

  useEffect(() => {
    onDirtyChange?.(isDirty);
  }, [
    customerId,
    bathroomCount,
    frequency,
    weeks,
    startDate,
    startTime,
    paymentMode,
    paymentAmount,
    bankType,
    transactionId,
    isDirty,
    onDirtyChange,
  ]);

  const bookingData = {
    customerId,
    bathroomCount,
    frequency,
    frequencyIntervalDays: selectedFrequency?.intervalDays,
    weeks,
    startDate,
    startTime,
    paymentMode,
    paymentAmount,
    amount: totalValue,
    totalVisits: estimatedVisitCount,
    bankType,
    receiverBankId: bankType,
    transactionId,
  };

  const resetForm = () => {
    setCustomerId("");
    setBathroomCount("");
    setFrequency("");
    setWeeks("");
    setStartDate("");
    setStartTime("");
    setPaymentMode("");
    setPaymentAmount("");
    setBankType("");
    setTransactionId("");
  };

  const handleConfirm = async () => {
    if (isSubmitting || submittingRef.current) return;
    submittingRef.current = true;
    setIsSubmitting(true);
    try {
      await onSubmit(bookingData);
      setFinalReviewOpen(false);
      setBookingStep(1);
      resetForm();
    } finally {
      submittingRef.current = false;
      setIsSubmitting(false);
    }
  };

  return (
    <Box>
      <Stepper
        activeStep={bookingStep - 1}
        alternativeLabel
        sx={{ mb: 3 }}
      >
        <Step>
          <StepLabel>Booking details</StepLabel>
        </Step>
        <Step>
          <StepLabel>Transaction and receiver bank</StepLabel>
        </Step>
      </Stepper>
      {bookingStep === 1 && (
        <Typography variant="subtitle2" sx={{ mb: 1.25, fontSize: 17 }}>
          Booking Details
        </Typography>
      )}
      {bookingStep === 1 && <Autocomplete
        fullWidth
        size="small"
        options={availableCustomers}
        value={selectedCustomer}
        onChange={(_, customer) => setCustomerId(customer?.id || "")}
        isOptionEqualToValue={(option, value) => option.id === value.id}
        getOptionKey={(customer) => customer.id}
        getOptionLabel={(customer) =>
          `${customer.name || ""} · ${customer.phone || "No mobile number"}`
        }

        // Filtering the customer by phone number
        filterOptions={(options, { inputValue }) => {
          const searchText = inputValue.trim().toLowerCase();
          const searchDigits = searchText.replace(/\D/g, "");
          return options.filter((customer) => {
            const phone = String(customer.phone || "");
            const searchableText =
              `${customer.name || ""} ${phone}`.toLowerCase();
            return (
              searchableText.includes(searchText) ||
              (searchDigits && phone.replace(/\D/g, "").includes(searchDigits))
            );
          });
        }}
        renderInput={(params) => (
          <TextField
            {...params}
            label="Customer name or mobile number"
            placeholder="Search by name or mobile number"
          />
        )}
        sx={{ mb: 2 }}
      />}

      <>
        {bookingStep === 1 && (
          <Paper variant="outlined" sx={{ p: { xs: 2, sm: 3 }, mb: 2 }}>
        <Grid
          container
          spacing={2}
          sx={{
            mt: 2,
            mb: 2,
            display: "grid",
            gridTemplateColumns: {
              xs: "minmax(0, 1fr)",
              sm: "repeat(3, minmax(0, 1fr))",
            },
            "& > *": { minWidth: 0 },
          }}
        >
          <Grid item xs={12} sm={6}>
            <TextField
              select
              fullWidth
              size="small"
              label="Bathrooms count"
              value={bathroomCount}
              onChange={(e) => setBathroomCount(Number(e.target.value))}
            >
              <MenuItem value="">Select bathrooms count</MenuItem>
              {[1, 2, 3, 4].map((n) => (
                <MenuItem key={n} value={n}>
                  {n} Bathroom{n > 1 ? "s" : ""} — {durationByBathrooms[n]} min
                </MenuItem>
              ))}
            </TextField>
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField
              select
              fullWidth
              size="small"
              label="Service frequency"
              value={frequency}
              onChange={(e) => setFrequency(e.target.value)}
            >
              <MenuItem value="">Select frequency</MenuItem>
              {frequencyOptions.map((frequency) => (
                <MenuItem key={frequency.id} value={frequency.value}>
                  {frequency.label}
                </MenuItem>
              ))}
            </TextField>
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField
              select
              fullWidth
              size="small"
              label="Subscription"
              value={weeks}
              disabled={frequency === "once" || compatibleSubscriptions.length === 0}
              onChange={(e) => setWeeks(Number(e.target.value))}
            >
              <MenuItem value="">Select subscription</MenuItem>
              {compatibleSubscriptions.map((subscription) => (
                <MenuItem key={subscription.id} value={subscription.weeks}>
                  {subscription.label}
                </MenuItem>
              ))}
            </TextField>
          </Grid>
          <Grid item xs={6} sm={3}>
            <TextField
              id="booking-start-date"
              fullWidth
              size="small"
              type="date"
              value={startDate}
              onChange={(e) => setStartDate(e.target.value)}
              inputProps={{ "aria-label": "Start date" }}
            />
          </Grid>
          <Grid item xs={6} sm={3}>
            <TextField
              id="booking-start-time"
              select
              fullWidth
              size="small"
              label="Start time"
              value={startTime}
              onChange={(e) => setStartTime(e.target.value)}
              disabled={!startDate || !bathroomCount}
              inputProps={{ "aria-label": "Start time" }}
            >
              <MenuItem value="">Select start time</MenuItem>
              {availableStarts.length === 0 && (
                <MenuItem value="">No slots free</MenuItem>
              )}
              {availableStarts.map((time) => (
                <MenuItem key={time} value={time}>
                  {fmtTime12(time)}
                </MenuItem>
              ))}
            </TextField>
          </Grid>
        </Grid>
        <Button
          fullWidth
          variant="contained"
          disabled={!bookingDetailsComplete}
          onClick={() => setReviewOpen(true)}
        >
          Next
        </Button>
          </Paper>
        )}

        {bookingStep === 2 && (
          <Paper variant="outlined" sx={{ p: { xs: 2, sm: 3 }, mb: 2 }}>
            <TransactionDetails
              paymentMode={paymentMode}
              setPaymentMode={setPaymentMode}
              paymentOptions={paymentOptions}
              accountOptions={accountOptions}
              paymentAmount={paymentAmount}
              setPaymentAmount={setPaymentAmount}
              bankType={bankType}
              setBankType={setBankType}
              transactionId={transactionId}
              setTransactionId={setTransactionId}
            />
            <Stack direction="row" spacing={1.5}>
              <Button fullWidth variant="outlined" onClick={() => setBookingStep(1)}>
                Back
              </Button>
              <Button
                fullWidth
                variant="contained"
                startIcon={<CheckIcon />}
                disabled={!transactionDetailsComplete || isSubmitting}
                onClick={() => setFinalReviewOpen(true)}
              >
                Book
              </Button>
            </Stack>
          </Paper>
        )}
      </>

      <Dialog
        open={reviewOpen}
        onClose={() => !isSubmitting && setReviewOpen(false)}
        fullWidth
        maxWidth="md"
      >
        <DialogTitle>
          <Stack direction="row" spacing={1} alignItems="center">
            <WarningAmberIcon color="warning" />
            <span>Confirm service booking</span>
          </Stack>
        </DialogTitle>
        <DialogContent dividers>
          <Box
            sx={{
              display: "grid",
              gridTemplateColumns: { xs: "1fr", md: "1fr 1fr" },
              gap: { xs: 3, md: 4 },
            }}
          >
            <Box>
              <Typography variant="subtitle2" fontWeight={700} sx={{ mb: 1.5 }}>
                Customer details
              </Typography>
              <Stack spacing={0.75}>
                {[
                  ["Name", selectedCustomer?.name],
                  ["Phone", selectedCustomer?.phone],
                  ["Door number", selectedCustomer?.doorNumber],
                  ["Block / Tower", selectedCustomer?.blockNumber],
                  ["Apartment", selectedCustomer?.apartmentNumber],
                  ["Address", selectedCustomer?.address],
                  ["Area", selectedCustomer?.area],
                  ["Pincode", selectedCustomer?.pincode],
                  ["City", selectedCustomer?.city],
                  ["Landmark", selectedCustomer?.landmark],
                ].map(([label, value]) => (
                  <Stack key={label} direction="row" spacing={2}>
                    <Typography
                      variant="body2"
                      fontWeight={700}
                      sx={{ minWidth: 125 }}
                    >
                      {label}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      {value || "Not provided"}
                    </Typography>
                  </Stack>
                ))}
              </Stack>
            </Box>
            <Box
              sx={{
                borderLeft: { xs: 0, md: 1 },
                borderColor: "divider",
                pl: { xs: 0, md: 4 },
              }}
            >
              <Typography variant="subtitle2" fontWeight={700} sx={{ mb: 1.5 }}>
                Booking details
              </Typography>
              <Stack spacing={0.75}>
                {[
                  [
                    "Bathrooms",
                    `${bathroomCount} Bathroom${Number(bathroomCount) > 1 ? "s" : ""}`,
                  ],
                  [
                    "Service frequency",
                    selectedFrequency?.label || "No service",
                  ],
                  [
                    "Subscription duration",
                    weeks
                      ? subscriptionOptions.find((subscription) => subscription.weeks === weeks)?.label || `${weeks} weeks`
                      : "Not provided",
                  ],
                  ["Start date", startDate],
                  ["Start time", fmtTime12(startTime)],
                  ["Visits generated", occurrences.length],
                  ["Estimated value", fmtMoney(totalValue)],
                ].map(([label, value]) => (
                  <Stack key={label} direction="row" spacing={2}>
                    <Typography
                      variant="body2"
                      fontWeight={700}
                      sx={{ minWidth: 125 }}
                    >
                      {label}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      {value || "Not provided"}
                    </Typography>
                  </Stack>
                ))}
              </Stack>
            </Box>
          </Box>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button
            onClick={() => setReviewOpen(false)}
            color="inherit"
            disabled={isSubmitting}
          >
            Cancel
          </Button>
          <Button
            onClick={() => {
              setReviewOpen(false);
              setBookingStep(2);
            }}
            variant="contained"
            disabled={isSubmitting}
          >
            Next
          </Button>
        </DialogActions>
      </Dialog>

      <Dialog
        open={finalReviewOpen}
        onClose={() => !isSubmitting && setFinalReviewOpen(false)}
        fullWidth
        maxWidth="md"
      >
        <DialogTitle>
          <Stack direction="row" spacing={1} alignItems="center">
            <WarningAmberIcon color="warning" />
            <span>Confirm booking details</span>
          </Stack>
        </DialogTitle>
        <DialogContent dividers>
          <Box
            sx={{
              display: "grid",
              gridTemplateColumns: { xs: "1fr", md: "1fr 1fr" },
              gap: { xs: 3, md: 4 },
            }}
          >
            <Box>
              <Typography variant="subtitle2" fontWeight={700} sx={{ mb: 1.5 }}>
                Customer and booking details
              </Typography>
              <Stack spacing={0.75}>
                {[
                  ["Customer", selectedCustomer?.name],
                  ["Phone", selectedCustomer?.phone],
                  ["Bathrooms", `${bathroomCount} Bathroom${Number(bathroomCount) > 1 ? "s" : ""}`],
                  ["Service frequency", selectedFrequency?.label || frequency],
                  ["Subscription", weeks ? subscriptionOptions.find((subscription) => subscription.weeks === weeks)?.label || `${weeks} weeks` : "Not provided"],
                  ["Start date", startDate],
                  ["Start time", fmtTime12(startTime)],
                  ["Visits generated", occurrences.length],
                ].map(([label, value]) => (
                  <Stack key={label} direction="row" spacing={2}>
                    <Typography variant="body2" fontWeight={700} sx={{ minWidth: 125 }}>
                      {label}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      {value || "Not provided"}
                    </Typography>
                  </Stack>
                ))}
              </Stack>
            </Box>
            <Box sx={{ borderLeft: { xs: 0, md: 1 }, borderColor: "divider", pl: { xs: 0, md: 4 } }}>
              <Typography variant="subtitle2" fontWeight={700} sx={{ mb: 1.5 }}>
                Transaction and receiver bank details
              </Typography>
              <Stack spacing={0.75}>
                {[
                  ["Payment mode", selectedPayment?.label || paymentMode],
                  ["Payment amount", paymentAmount],
                  ["Transaction ID", transactionId],
                  ["Receiver bank", selectedAccount?.label || "Not provided"],
                  ["Estimated value", fmtMoney(totalValue)],
                ].map(([label, value]) => (
                  <Stack key={label} direction="row" spacing={2}>
                    <Typography variant="body2" fontWeight={700} sx={{ minWidth: 125 }}>
                      {label}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      {value || "Not provided"}
                    </Typography>
                  </Stack>
                ))}
              </Stack>
            </Box>
          </Box>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2 }}>
          <Button onClick={() => setFinalReviewOpen(false)} color="inherit" disabled={isSubmitting}>
            Back
          </Button>
          <Button
            onClick={handleConfirm}
            variant="contained"
            disabled={isSubmitting}
            startIcon={isSubmitting ? <CircularProgress size={18} color="inherit" /> : <CheckIcon />}
          >
            {isSubmitting ? "Scheduling..." : "Book"}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
