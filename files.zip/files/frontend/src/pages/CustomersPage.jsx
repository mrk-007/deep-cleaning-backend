import { useState } from "react";
import Box from "@mui/material/Box";
import Paper from "@mui/material/Paper";
import Stack from "@mui/material/Stack";
import Typography from "@mui/material/Typography";
import Dialog from "@mui/material/Dialog";
import DialogContent from "@mui/material/DialogContent";
import DialogTitle from "@mui/material/DialogTitle";
import IconButton from "@mui/material/IconButton";
import PeopleAltOutlinedIcon from "@mui/icons-material/PeopleAltOutlined";
import CloseIcon from "@mui/icons-material/Close";
import CustomerRegistrationForm from "../components/customer-components/CustomerRegistrationForm.jsx";
import CustomerDetails from "../components/customer-components/CustomerDetails.jsx";
import UnsavedChangesDialog from "../components/common-components/UnsavedChangesDialog.jsx";

export default function CustomersPage({
  customers,
  bookings,
  invoices,
  onAddCustomer,
  onUpdateCustomer,
  onPrintInvoice,
  onCustomerCreated,
  onDirtyChange,
  customerView = "details",
  onCustomerViewChange,
}) {
  const [registrationDialogOpen, setRegistrationDialogOpen] = useState(false);
  const [registrationFormDirty, setRegistrationFormDirty] = useState(false);
  const [discardDialogOpen, setDiscardDialogOpen] = useState(false);
  const [registrationFormKey, setRegistrationFormKey] = useState(0);

  const closeRegistrationDialog = () => {
    if (registrationFormDirty) {
      setDiscardDialogOpen(true);
      return;
    }
    setRegistrationDialogOpen(false);
  };

  const discardRegistrationChanges = () => {
    setDiscardDialogOpen(false);
    setRegistrationDialogOpen(false);
    setRegistrationFormDirty(false);
    setRegistrationFormKey((key) => key + 1);
    onDirtyChange?.(false);
  };

  return (
    <Box
      sx={{
        width: "100%",
        maxWidth: customerView === "registration" ? 980 : 1480,
        mr: "auto",
        pb: 4,
      }}
    >
      <Box
        sx={{
          display: "grid",
          gridTemplateColumns: {
            xs: "1fr",
            sm: customerView === "details" ? "minmax(0, 1fr) auto" : "1fr",
          },
          alignItems: "start",
          columnGap: 2,
          rowGap: 1,
          mb: 3,
        }}
      >
        <Box>
          <Stack direction="row" spacing={1.25} alignItems="center">
            <PeopleAltOutlinedIcon color="primary" />
            <Typography variant="h5" sx={{ fontWeight: 800, lineHeight: 1.1 }}>
              {customerView === "registration" ? "Customer registration" : "Customer details"}
            </Typography>
          </Stack>
          <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>
            {customerView === "registration"
              ? "Register a customer before creating a service order."
              : "View customer contact details and subscription history."}
          </Typography>
        </Box>
      </Box>

      {customerView === "registration" ? (
        <Paper
          variant="outlined"
          sx={{ width: "100%", p: { xs: 2, sm: 3 } }}
        >
          <CustomerRegistrationForm
            onDirtyChange={onDirtyChange}
            onSubmit={async (data) => {
              const customer = await onAddCustomer(data);
              if (customer) {
                onDirtyChange?.(false);
                onCustomerCreated?.(customer);
              }
            }}
          />
        </Paper>
      ) : (
        <>
          <CustomerDetails
            customers={customers}
            bookings={bookings}
            invoices={invoices}
            onPrintInvoice={onPrintInvoice}
            onUpdateCustomer={onUpdateCustomer}
            onAddCustomerClick={() => setRegistrationDialogOpen(true)}
          />
          <Dialog
            open={registrationDialogOpen}
            onClose={closeRegistrationDialog}
            fullWidth
            maxWidth="sm"
          >
            <DialogTitle sx={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
              Add customer
              <IconButton
                aria-label="Close add customer dialog"
                onClick={closeRegistrationDialog}
                edge="end"
                size="small"
              >
                <CloseIcon fontSize="small" />
              </IconButton>
            </DialogTitle>
            <DialogContent dividers>
              <CustomerRegistrationForm
                key={registrationFormKey}
                onDirtyChange={(dirty) => {
                  setRegistrationFormDirty(dirty);
                  onDirtyChange?.(dirty);
                }}
                onSubmit={async (data) => {
                  const customer = await onAddCustomer(data);
                  if (customer) {
                    onDirtyChange?.(false);
                    setRegistrationFormDirty(false);
                    setRegistrationDialogOpen(false);
                    onCustomerCreated?.(customer);
                  }
                }}
              />
            </DialogContent>
          </Dialog>
          <UnsavedChangesDialog
            open={discardDialogOpen}
            onDiscard={discardRegistrationChanges}
            onCancel={() => setDiscardDialogOpen(false)}
          />
        </>
      )}
    </Box>
  );
}
