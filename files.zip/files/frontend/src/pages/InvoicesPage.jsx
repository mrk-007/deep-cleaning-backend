import { useState, useMemo } from "react";
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import CloseIcon from "@mui/icons-material/Close";
import InvoicePrintable from "../components/common-components/InvoicePrintable.jsx";

import {
  Box,
  Paper,
  Typography,
  TextField,
  InputAdornment,
  MenuItem,
  IconButton,
  Stack,
  Divider,
  Chip,
  Tooltip,
} from "@mui/material";

import SearchIcon from "@mui/icons-material/Search";
import PrintIcon from "@mui/icons-material/Print";
import ReceiptLongOutlinedIcon from "@mui/icons-material/ReceiptLongOutlined";
import VisibilityOutlinedIcon from "@mui/icons-material/VisibilityOutlined";

import {
  norm,
  fmtDateHuman,
  fmtMoney,
  fmtTime12,
} from "../utils/scheduling.js";

function isDateInPeriod(dateString, period) {
  if (!period || !dateString) return !period;
  const date = new Date(`${dateString}T00:00:00`);
  if (Number.isNaN(date.getTime())) return false;

  const today = new Date();
  today.setHours(0, 0, 0, 0);
  if (period === "today") return date.getTime() === today.getTime();

  const start = new Date(today);
  if (period === "week") {
    start.setDate(today.getDate() - ((today.getDay() + 6) % 7));
  } else {
    start.setDate(1);
  }
  const end = new Date(start);
  if (period === "week") end.setDate(start.getDate() + 7);
  else end.setMonth(start.getMonth() + 1);
  return date >= start && date < end;
}

export default function InvoicesPage({
  invoices,
  customerById,
  bookings,
  onPrint,
}) {
  const [search, setSearch] = useState("");
  const [dateFilter, setDateFilter] = useState("");
  const [periodFilter, setPeriodFilter] = useState("all");
  const [previewInvoice, setPreviewInvoice] = useState(null);
  const bookingById = useMemo(() => {
    const m = {};
    bookings.forEach((b) => (m[b.id] = b));
    return m;
  }, [bookings]);
  const sorted = useMemo(
    () => invoices.filter((invoice) => invoice.status !== "cancelled"),
    [invoices],
  );
  const filtered = useMemo(() => {
    const q = norm(search);
    return sorted.filter((inv) => {
      const cust = customerById[inv.customerId];
      const invoiceBookings = (inv.bookingIds || [inv.bookingId])
        .map((id) => bookingById[id])
        .filter(Boolean);
      const invoiceEntryDate = inv.createdDate || inv.paidDate;
      if (dateFilter && invoiceEntryDate !== dateFilter) return false;
      if (
        periodFilter !== "all" &&
        !isDateInPeriod(invoiceEntryDate, periodFilter)
      ) {
        return false;
      }
      const b = invoiceBookings[0];
      if (!q) return true;
      return (
        norm(cust?.name).includes(q) ||
        norm(cust?.phone).includes(q) ||
        norm(b?.date).includes(q)
      );
    });
  }, [sorted, search, dateFilter, periodFilter, customerById, bookingById]);

  return (
    <Box sx={{ maxWidth: 1180, mx: "auto", pb: 4 }}>
      {/* Header */}
      <Box>
        <Stack
          direction="row"
          spacing={1.25}
          alignItems="center"
          sx={{ mb: 1 }}
        >
          <ReceiptLongOutlinedIcon color="primary" />
          <Typography variant="h5" sx={{ fontWeight: 800, lineHeight: 1.1 }}>
            Invoices
          </Typography>
        </Stack>
        <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
          Keep track of every booking payment in one place.
        </Typography>
        <Stack
          direction={{ xs: "column", sm: "row" }}
          spacing={1.5}
          sx={{ mb: 2.5 }}
        >
          <TextField
            size="small"
            placeholder="Search invoices"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            fullWidth
            sx={{ "& .MuiOutlinedInput-root": { borderRadius: 0.5 } }}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon fontSize="small" />
                </InputAdornment>
              ),
            }}
          />
          <TextField
            select
            size="small"
            label="Show"
            value={periodFilter}
            onChange={(e) => setPeriodFilter(e.target.value)}
            sx={{ minWidth: { sm: 150 } }}
          >
            <MenuItem value="all">All invoices</MenuItem>
            <MenuItem value="today">Today</MenuItem>
            <MenuItem value="week">This week</MenuItem>
            <MenuItem value="month">This month</MenuItem>
          </TextField>
          <TextField
            size="small"
            type="date"
            value={dateFilter}
            onChange={(e) => setDateFilter(e.target.value)}
            sx={{ minWidth: { sm: 180 } }}
            InputLabelProps={{ shrink: true }}
            inputProps={{ "aria-label": "Filter invoices by date" }}
          />
        </Stack>
      </Box>

      {filtered.length === 0 ? (
        <Paper variant="outlined" sx={{ p: 5, textAlign: "center" }}>
          <Typography variant="body2" color="text.secondary">
            {invoices.length === 0
              ? "No invoices yet."
              : "No invoices match your search."}
          </Typography>
        </Paper>
      ) : (
        <Paper
          variant="outlined"
          sx={{ overflow: "hidden", bgcolor: "transparent" }}
        >
          <Stack divider={<Divider />}>
            {filtered.map((inv) => {
              const invoiceBookings = (inv.bookingIds || [inv.bookingId])
                .map((id) => bookingById[id])
                .filter(Boolean);
              const b = invoiceBookings[0];
              const cust = customerById[inv.customerId];
              return (
                <Stack
                  key={inv.id}
                  direction={{ xs: "column", md: "row" }}
                  alignItems={{ xs: "stretch", md: "center" }}
                  spacing={{ xs: 2, md: 3 }}
                  sx={{
                    px: { xs: 2, sm: 2.5 },
                    py: { xs: 2, sm: 2.25 },
                    gap: { xs: 1.5, md: 3 },
                    justifyContent: { xs: "stretch", md: "space-between" },
                    borderLeft: 4,
                    borderLeftColor: "primary.main",
                    bgcolor: "background.paper",
                    cursor: "pointer",
                    transition: "background-color 160ms ease",
                    "&:hover": { bgcolor: "action.hover" },
                  }}
                  onClick={() =>
                    setPreviewInvoice({
                      invoice: inv,
                      customer: cust,
                      booking: b,
                      bookings: invoiceBookings,
                    })
                  }
                >
                  <Stack
                    direction="row"
                    alignItems="center"
                    spacing={1.5}
                    minWidth={0}
                    flex={1}
                    sx={{ minWidth: 0 }}
                  >
                    <Box
                      sx={{
                        display: "grid",
                        placeItems: "center",
                        flexShrink: 0,
                        width: 42,
                        height: 42,
                        borderRadius: 2,
                        bgcolor: "primary.main",
                        color: "primary.contrastText",
                      }}
                    >
                      <ReceiptLongOutlinedIcon fontSize="small" />
                    </Box>
                    <Box minWidth={0}>
                      <Typography variant="body1" fontWeight={600} noWrap>
                        {cust?.name || "Unknown"}
                      </Typography>
                      <Typography
                        variant="caption"
                        color="text.secondary"
                        noWrap
                        sx={{ display: "block", mt: 0.35 }}
                      >
                        {invoiceBookings.length > 1
                          ? `${invoiceBookings.length} visits · ${fmtDateHuman(invoiceBookings[0].date)} to ${fmtDateHuman(invoiceBookings[invoiceBookings.length - 1].date)}`
                          : b
                            ? `${fmtDateHuman(b.date)} · ${b.startTime ? fmtTime12(b.startTime) : "unscheduled"} · ${b.bathroomCount} bath${b.bathroomCount > 1 ? "s" : ""}`
                            : "Booking removed"}
                      </Typography>
                    </Box>
                  </Stack>
                  <Stack
                    direction="row"
                    spacing={{ xs: 1, sm: 1.5 }}
                    alignItems="center"
                    flexWrap="wrap"
                    useFlexGap
                    sx={{
                      width: { xs: "100%", md: "auto" },
                      ml: { md: "auto" },
                      flexShrink: 0,
                      justifyContent: "flex-end",
                      pl: { md: 2.5 },
                      borderLeft: { md: 1 },
                      borderColor: { md: "divider" },
                    }}
                    onClick={(event) => event.stopPropagation()}
                  >
                    <Box
                      sx={{
                        textAlign: "right",
                        minWidth: { sm: 120 },
                        mr: { sm: 0.5 },
                        pt: 1.9,
                      }}
                    >
                      <Typography
                        variant="h6"
                        fontWeight={800}
                        sx={{ lineHeight: 1.1, whiteSpace: "nowrap" }}
                      >
                        {fmtMoney(inv.amount)}
                      </Typography>
                    </Box>
                    <Box sx={{ pt: 1.5 }}>
                      <Chip
                        size="small"
                        color={inv.status === "paid" ? "success" : "warning"}
                        label={inv.status === "paid" ? "Paid" : "Pending"}
                        sx={{
                          display: { xs: "inline-flex", md: "inline-flex" },
                        }}
                      />
                    </Box>

                    <Tooltip title="Preview invoice">
                      <IconButton
                        size="small"
                        aria-label="Preview invoice"
                        onClick={() =>
                          setPreviewInvoice({
                            invoice: inv,
                            customer: cust,
                            booking: b,
                            bookings: invoiceBookings,
                          })
                        }
                      >
                        <VisibilityOutlinedIcon fontSize="small" />
                      </IconButton>
                    </Tooltip>
                    <Tooltip title="Print / Save as PDF">
                      <IconButton
                        size="small"
                        onClick={() =>
                          onPrint({
                            invoice: inv,
                            customer: cust,
                            booking: b,
                            bookings: invoiceBookings,
                          })
                        }
                      >
                        <PrintIcon fontSize="small" />
                      </IconButton>
                    </Tooltip>
                  </Stack>
                </Stack>
              );
            })}
          </Stack>
        </Paper>
      )}

      <Dialog
        open={!!previewInvoice}
        onClose={() => {}}
        disableEscapeKeyDown
        fullWidth
        maxWidth="sm"
      >
        <DialogTitle
          sx={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            pr: 1,
          }}
        >
          Invoice preview
          <IconButton
            aria-label="Close invoice preview"
            onClick={() => setPreviewInvoice(null)}
          >
            <CloseIcon />
          </IconButton>
        </DialogTitle>
        <DialogContent dividers>
          {previewInvoice && <InvoicePrintable {...previewInvoice} />}
        </DialogContent>
      </Dialog>
    </Box>
  );
}
