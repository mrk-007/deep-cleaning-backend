import { useEffect, useState } from "react";
import Box from "@mui/material/Box";
import Paper from "@mui/material/Paper";
import Typography from "@mui/material/Typography";
import TextField from "@mui/material/TextField";
import InputAdornment from "@mui/material/InputAdornment";
import Stack from "@mui/material/Stack";
import Divider from "@mui/material/Divider";
import Grid from "@mui/material/Grid";
import SettingsIcon from '@mui/icons-material/Settings';
import PriceChangeIcon from '@mui/icons-material/PriceChange';
import AccessTimeIcon from "@mui/icons-material/AccessTime";
import { updatePricing as updatePricingRecord } from "../api/pricing.js";
import { updateServiceDuration } from "../api/serviceDurations.js";

export default function SettingsPage({
  pricing,
  durations,
  pricingRecords,
  serviceDurationRecords,
  run,
}) {
  const [pricingDraft, setPricingDraft] = useState(pricing);
  const [durationsDraft, setDurationsDraft] = useState(durations);

  useEffect(() => setPricingDraft(pricing), [pricing]);
  useEffect(() => setDurationsDraft(durations), [durations]);

  const savePricing = async (nextPricing) => {
    setPricingDraft(nextPricing);
    await run(() =>
      Promise.all(
        pricingRecords.map((record) => {
          const bathroomCount = record.bathroomCountId?.bathroomCount;
          return updatePricingRecord(record._id, {
            price: Number(nextPricing[bathroomCount]),
          });
        }),
      ),
    );
  };

  const saveDurations = async (nextDurations) => {
    setDurationsDraft(nextDurations);
    await run(() =>
      Promise.all(
        serviceDurationRecords.map((record, index) =>
          updateServiceDuration(record._id, {
            durationMinutes: Number(nextDurations[index + 1]),
          }),
        ),
      ),
    );
  };

  return (
    <Box sx={{ maxWidth: 1180, mx: "auto", width: "100%" }}>
      <Stack direction="row" spacing={1.25} alignItems="center" sx={{ mb: 1 }}>
        <SettingsIcon color="primary" />
        <Typography variant="h5" sx={{ fontWeight: 800, lineHeight: 1.1 }}>
          Settings
        </Typography>
      </Stack>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
        Manage service rates and execution timelines.
      </Typography>

      <Grid container spacing={{ xs: 2, md: 3 }} alignItems="stretch">
        {/* Visiting Pricing  */}
        <Grid size={{ xs: 12, md: 6 }} sx={{ display: "flex" }}>
          <Paper
            variant="outlined"
            sx={{
              width: "100%",
              height: "100%",
              overflow: "hidden",
              display: "flex",
              flexDirection: "column",
              borderRadius: 1,
              boxShadow: "0 6px 20px rgba(20, 20, 20, 0.04)",
            }}
          >
            <Box
              sx={{
                px: { xs: 2.25, sm: 3 },
                py: 2.25,
                minHeight: 118,
                display: "flex",
                alignItems: "center",
                bgcolor: "#FFF8F5",
                borderBottom: 1,
                borderColor: "divider",
              }}
            >
              <Stack direction="row" spacing={1.5} alignItems="center">
                <Box
                  sx={{
                    width: 38,
                    height: 38,
                    display: "grid",
                    placeItems: "center",
                    borderRadius: 2,
                    bgcolor: "rgba(226,109,79,0.1)",
                    color: "primary.main",
                  }}
                >
                  <PriceChangeIcon />
                </Box>
                <Box>
                  <Typography variant="h6" sx={{ lineHeight: 1.2, fontWeight: 800 }}>
                    Service Pricing
                  </Typography>
                  <Typography variant="caption" color="text.secondary">
                    Manage pricing across service tiers.
                  </Typography>
                </Box>
              </Stack>
            </Box>
            <Box             sx={{ px: { xs: 2, sm: 3 }, py: 1.5, flex: 1 }}>
              <Box
                sx={{
                  display: "grid",
                  gridTemplateColumns: {
                    xs: "minmax(0, 1fr) minmax(96px, 116px)",
                    sm: "minmax(0, 1fr) 138px",
                  },
                  gap: { xs: 1, sm: 2 },
                  px: 0,
                  py: 1,
                }}
              >
                <Typography variant="overline" color="text.secondary">
                  Service size
                </Typography>
                <Typography
                  variant="overline"
                  color="text.secondary"
                  sx={{ textAlign: "right" }}
                >
                  Price per visit
                </Typography>
              </Box>
              <Stack divider={<Divider />}>
                {[1, 2, 3, 4].map((n) => (
                  <Stack
                    key={n}
                    direction="row"
                    justifyContent="space-between"
                    alignItems="center"
                    sx={{
                      display: "grid",
                      gridTemplateColumns: "minmax(0, 1fr) auto",
                      py: 1.5,
                      gap: 2,
                      minWidth: 0,
                    }}
                  >
                    <Stack
                      direction="row"
                      spacing={{ xs: 1, sm: 1.25 }}
                      alignItems="center"
                      sx={{ minWidth: 0 }}
                    >
                      <Box
                        sx={{
                          width: 34,
                          height: 34,
                          display: "grid",
                          placeItems: "center",
                          borderRadius: 2,
                          bgcolor: "rgba(226,109,79,0.1)",
                          color: "primary.main",
                          fontWeight: 700,
                        }}
                      >
                        {n}
                      </Box>
                      <Box sx={{ minWidth: 0 }}>
                        <Typography
                          variant="body2"
                          sx={{ fontWeight: 600, lineHeight: 1.25 }}
                        >
                          {n} Bathroom{n > 1 ? "s" : ""}
                        </Typography>
                        <Stack
                          direction="row"
                          spacing={0.5}
                          alignItems="center"
                        >
                          <AccessTimeIcon
                            sx={{
                              fontSize: 18,
                              width: 16,
                              flexShrink: 0,
                              color: "text.secondary",
                            }}
                          />
                          <Typography variant="caption" color="text.secondary">
                            {durations[n]} min visit
                          </Typography>
                        </Stack>
                      </Box>
                    </Stack>
                    <TextField
                      size="small"
                      type="number"
                      value={pricingDraft[n]}
                      sx={{
                        width: { xs: 80, sm: 90 },
                        justifySelf: "end",
                        flexShrink: 0,
                      }}
                      inputProps={{ min: 0 }}
                      InputProps={{
                        startAdornment: (
                          <InputAdornment position="start">₹</InputAdornment>
                        ),
                      }}
                      onChange={(e) =>
                        savePricing({ ...pricingDraft, [n]: Number(e.target.value) })
                      }
                    />
                  </Stack>
                ))}
              </Stack>
            </Box>
          </Paper>
        </Grid>






        {/* Cleaning Time Table */}
        <Grid size={{ xs: 12, md: 6 }} sx={{ display: "flex" }}>
          <Paper
            variant="outlined"
            sx={{
              width: "100%",
              height: "100%",
              overflow: "hidden",
              display: "flex",
              flexDirection: "column",
              borderRadius: 1,
              boxShadow: "0 6px 20px rgba(20, 20, 20, 0.04)",
            }}
          >
            <Box
              sx={{
                px: { xs: 2.25, sm: 3 },
                py: 2.25,
                minHeight: 118,
                display: "flex",
                alignItems: "center",
                bgcolor: "#FFF8F5",
                borderBottom: 1,
                borderColor: "divider",
              }}
            >
              <Stack direction="row" spacing={1.5} alignItems="center">
                <Box
                  sx={{
                    width: 38,
                    height: 38,
                    display: "grid",
                    placeItems: "center",
                    borderRadius: 2,
                    bgcolor: "rgba(226,109,79,0.1)",
                    color: "primary.main",
                  }}
                >
                  <AccessTimeIcon />
                </Box>
                <Box>
                  <Typography variant="h6" sx={{ lineHeight: 1.2, fontWeight: 800 }}>
                    Service Duration
                  </Typography>
                  <Typography variant="caption" color="text.secondary">
                    Manage standard service durations by service type.
                  </Typography>
                </Box>
              </Stack>
            </Box>
            <Box sx={{ px: { xs: 2, sm: 3 }, py: 1.5, flex: 1 }}>
              <Box
                sx={{
                  display: "grid",
                  gridTemplateColumns: {
                    xs: "minmax(0, 1fr) minmax(96px, 116px)",
                    sm: "minmax(0, 1fr) 138px",
                  },
                  gap: { xs: 1, sm: 2 },
                  px: 0,
                  py: 1,
                }}
              >
                <Typography variant="overline" color="text.secondary">
                  Bathroom count
                </Typography>
                <Typography
                  variant="overline"
                  color="text.secondary"
                  sx={{ textAlign: "right" }}
                >
                  Minutes per visit
                </Typography>
              </Box>
              <Stack divider={<Divider />}>
                {[1, 2, 3, 4].map((n) => (
                  <Stack
                    key={n}
                    direction="row"
                    justifyContent="space-between"
                    alignItems="center"
                    sx={{
                      display: "grid",
                      gridTemplateColumns: "minmax(0, 1fr) auto",
                      py: 1.5,
                      gap: 2,
                      minWidth: 0,
                    }}
                  >
                    <Typography
                      variant="body2"
                      sx={{ fontWeight: 600, lineHeight: 1.25, minWidth: 0 }}
                    >
                      {n} Bathroom{n > 1 ? "s" : ""}
                    </Typography>
                    <TextField
                      size="small"
                      type="number"
                      value={durationsDraft[n]}
                      sx={{ width: { xs: 80, sm: 90 }, flexShrink: 0 }}
                      inputProps={{ min: 1, max: 1440 }}
                      InputProps={{
                        endAdornment: (
                          <InputAdornment position="end">min</InputAdornment>
                        ),
                      }}
                      onChange={(e) =>
                        saveDurations({
                          ...durationsDraft,
                          [n]: Number(e.target.value),
                        })
                      }
                    />
                  </Stack>
                ))}
              </Stack>
            </Box>
          </Paper>
        </Grid>
      </Grid>
    </Box>
  );
}
