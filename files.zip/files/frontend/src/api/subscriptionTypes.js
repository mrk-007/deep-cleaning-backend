import { get, post, put, del } from "../utils/api.js";

export const listSubscriptionTypes = (activeStatusId = "") =>
  get(
    activeStatusId
      ? `/subscription-types?activeStatusId=${encodeURIComponent(activeStatusId)}`
      : "/subscription-types",
  );
export const getSubscriptionType = (subscriptionId) =>
  get(`/subscription-types/${subscriptionId}`);
export const createSubscriptionType = (data) =>
  post("/subscription-types", data);
export const updateSubscriptionType = (subscriptionId, data) =>
  put(`/subscription-types/${subscriptionId}`, data);
export const deleteSubscriptionType = (subscriptionId) =>
  del(`/subscription-types/${subscriptionId}`);
