import { get, post, put, del } from "../utils/api.js";

export const listServiceDurations = (activeStatusId = "") =>
  get(
    activeStatusId
      ? `/service-durations?activeStatusId=${encodeURIComponent(activeStatusId)}`
      : "/service-durations",
  );
export const getServiceDuration = (durationId) =>
  get(`/service-durations/${durationId}`);
export const createServiceDuration = (data) => post("/service-durations", data);
export const updateServiceDuration = (durationId, data) =>
  put(`/service-durations/${durationId}`, data);
export const deleteServiceDuration = (durationId) =>
  del(`/service-durations/${durationId}`);
