import { get, post, patch, put } from "../utils/api.js";

export const subscriptionWeeks = (subscriptionName = "") => {
  const normalized = String(subscriptionName).toLowerCase().replace(/[^a-z0-9]/g, "");
  if (normalized.includes("standard") || normalized.includes("nosub")) return 1;

  const monthMatch = normalized.match(/(\d+)month/);
  if (monthMatch) return Number(monthMatch[1]) * 4;
  if (normalized.includes("annual") || normalized.includes("1year")) return 48;
  return 1;
};

const frequencyValue = (frequencyName = "") => {
  const normalized = String(frequencyName).toLowerCase().replace(/[^a-z0-9]/g, "");
  if (normalized === "once" || normalized.includes("onetime")) return "once";
  if (
    normalized.includes("biweekly") ||
    normalized.includes("every2weeks") ||
    normalized.includes("2weeks")
  ) return "biweekly";
  if (
    normalized.includes("weekly") ||
    normalized.includes("everyweek") ||
    normalized.includes("onceaweek") ||
    normalized.includes("perweek")
  ) return "weekly";
  if (
    normalized.includes("monthly") ||
    normalized.includes("everymonth") ||
    normalized.includes("onceamonth") ||
    normalized.includes("permonth")
  ) return "monthly";
  return String(frequencyName).toLowerCase();
};

const normalizeBooking = (booking) => ({
  ...booking,
  id: booking.id ?? booking._id,
  customerId: booking.customerReference?._id ?? booking.customerReference ?? booking.customerId?._id ?? booking.customerId,
  bathroomCount: booking.bathroomCount ?? (booking.bathroomCountReference ?? booking.bathroomCountId)?.bathroomCount,
  pricingId: booking.pricingReference?._id ?? booking.pricingReference ?? booking.pricingId,
  serviceDurationId: booking.serviceDurationReference?._id ?? booking.serviceDurationReference ?? booking.serviceDurationId,
  serviceFrequencyId: booking.serviceFrequencyReference?._id ?? booking.serviceFrequencyReference ?? booking.serviceFrequencyId,
  serviceFrequencyName: (booking.serviceFrequencyReference ?? booking.serviceFrequencyId)?.frequencyName ?? "",
  serviceFrequencyIntervalDays:
    (booking.serviceFrequencyReference ?? booking.serviceFrequencyId)?.intervalDays ?? null,
  subscriptionTypeId:
    booking.subscriptionTypeReference?._id ?? booking.subscriptionTypeReference ?? booking.subscriptionTypeId?._id ?? booking.subscriptionTypeId,
  subscriptionTypeName: (booking.subscriptionTypeReference ?? booking.subscriptionTypeId)?.subscriptionName ?? "",
  subscriptionId:
    booking.subscriptionId ??
      booking.subscriptionReference?._id ??
      booking.subscriptionReference ??
      null,
  timeSlotId: booking.timeSlotReference?._id ?? booking.timeSlotReference ?? booking.timeSlotId?._id ?? booking.timeSlotId,
  paymentMethodId: booking.paymentMethodReference?._id ?? booking.paymentMethodReference ?? booking.paymentMethodId?._id ?? booking.paymentMethodId,
  receiverBankId: booking.paymentAccountReference?._id ?? booking.paymentAccountReference ?? booking.receiverBankId?._id ?? booking.receiverBankId,
  date: (booking.bookingDate ?? booking.startDateTime ?? "").slice(0, 10),
  startTime: booking.startDateTime
    ? new Date(booking.startDateTime).toISOString().slice(11, 16)
    : "",
  endTime: booking.endDateTime
    ? new Date(booking.endDateTime).toISOString().slice(11, 16)
    : "",
  frequency:
    booking.frequency ?? frequencyValue((booking.serviceFrequencyReference ?? booking.serviceFrequencyId)?.frequencyName),
  weeks:
    booking.weeks ??
    subscriptionWeeks((booking.subscriptionTypeReference ?? booking.subscriptionTypeId)?.subscriptionName),
  status: String(
    booking.status ??
      (booking.isCancelled
        ? "cancelled"
        : booking.isCompleted
          ? "completed"
          : "scheduled"),
  ).toLowerCase(),
});

export const listBookings = (filters = {}) => {
  const params = new URLSearchParams(
    Object.entries(filters).filter(([, value]) => value !== undefined && value !== ""),
  ).toString();
  return get(params ? `/bookings?${params}` : "/bookings").then((bookings) =>
    bookings.map(normalizeBooking),
  );
};
export const getBooking = async (bookingId) => {
  const response = await get(`/bookings/${bookingId}`);
  return { ...response, booking: normalizeBooking(response.booking) };
};
export const createBooking = (data) => post("/bookings", data);
export const updateBooking = (bookingId, data) => put(`/bookings/${bookingId}`, data);
export const cancelBooking = (bookingId) => patch(`/bookings/${bookingId}/cancel`, {});
export const completeBooking = (bookingId, completionPhoto) =>
  patch(`/bookings/${bookingId}/complete`, { completionPhoto: completionPhoto || null });

export const getAvailableSlots = (params = {}) => {
  const query = new URLSearchParams(params).toString();
  return get(`/bookings/availability?${query}`);
};
