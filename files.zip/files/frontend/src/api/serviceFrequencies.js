import { get, post, put, del } from "../utils/api.js";

export const listServiceFrequencies = (activeStatusId = "") =>
  get(
    activeStatusId
      ? `/service-frequencies?activeStatusId=${encodeURIComponent(activeStatusId)}`
      : "/service-frequencies",
  );
export const getServiceFrequency = (frequencyId) =>
  get(`/service-frequencies/${frequencyId}`);
export const createServiceFrequency = (data) =>
  post("/service-frequencies", data);
export const updateServiceFrequency = (frequencyId, data) =>
  put(`/service-frequencies/${frequencyId}`, data);
export const deleteServiceFrequency = (frequencyId) =>
  del(`/service-frequencies/${frequencyId}`);
