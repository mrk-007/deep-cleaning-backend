import { get, post, put, del } from "../utils/api.js";

export const listPaymentMethods = (activeStatusId = "") =>
  get(
    activeStatusId
      ? `/payment-methods?activeStatusId=${encodeURIComponent(activeStatusId)}`
      : "/payment-methods",
  );
export const getPaymentMethod = (paymentMethodId) =>
  get(`/payment-methods/${paymentMethodId}`);
export const createPaymentMethod = (data) => post("/payment-methods", data);
export const updatePaymentMethod = (paymentMethodId, data) =>
  put(`/payment-methods/${paymentMethodId}`, data);
export const deletePaymentMethod = (paymentMethodId) =>
  del(`/payment-methods/${paymentMethodId}`);
