import { get } from "../utils/api.js";

export const checkHealth = () => get("/health");
