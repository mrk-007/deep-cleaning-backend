import { get, post, put, del } from "../utils/api.js";

export const listBathroomCounts = (activeStatusId = "") =>
  get(
    activeStatusId
      ? `/bathroom-counts?activeStatusId=${encodeURIComponent(activeStatusId)}`
      : "/bathroom-counts",
  );
export const getBathroomCount = (bathroomCountId) =>
  get(`/bathroom-counts/${bathroomCountId}`);
export const createBathroomCount = (data) => post("/bathroom-counts", data);
export const updateBathroomCount = (bathroomCountId, data) =>
  put(`/bathroom-counts/${bathroomCountId}`, data);
export const deleteBathroomCount = (bathroomCountId) =>
  del(`/bathroom-counts/${bathroomCountId}`);
