import { get } from "../utils/api.js";

export const listPaymentMasters = () => get("/payment-masters?isActive=true");
