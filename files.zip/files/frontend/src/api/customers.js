import { get, post, put, del } from "../utils/api.js";

const toBackendCustomer = (customer) => ({
	name: customer.name,
	phoneNumber: customer.phoneNumber ?? customer.phone,
	address: customer.address ?? "",
	doorNo: customer.doorNo ?? customer.doorNumber ?? "",
	block: customer.block ?? customer.blockNumber ?? "",
	apartmentName: customer.apartmentName ?? customer.apartmentNumber ?? "",
	landmark: customer.landmark ?? "",
	area: customer.area ?? "",
	city: customer.city ?? "",
	pincode: customer.pincode ?? "",
	...(customer.activeStatusId || customer.activeStatusReference
		? {
			activeStatusId:
				customer.activeStatusId ?? customer.activeStatusReference,
		}
		: {}),
});

const normalizeCustomer = (customer) => {
	const rawId = customer.id ?? customer._id;
	const id = rawId?._id ?? rawId?.$oid ?? rawId;

	return {
	...customer,
	id: id ? String(id) : "",
	phone: customer.phone ?? customer.phoneNumber,
	doorNumber: customer.doorNumber ?? customer.doorNo,
	blockNumber: customer.blockNumber ?? customer.block,
	apartmentNumber: customer.apartmentNumber ?? customer.apartmentName,
	area: customer.area || customer.landmark || "",
	};
};

export const listCustomers = (search = "") =>
  get(search ? `/customers?search=${encodeURIComponent(search)}` : "/customers").then(
		(customers) => customers.map(normalizeCustomer),
	);
export const getCustomer = async (customerId) =>
	normalizeCustomer(await get(`/customers/${customerId}`));
export const createCustomer = async (data) =>
	normalizeCustomer(await post("/customers", toBackendCustomer(data)));
export const updateCustomer = (customerId, data) =>
  put(`/customers/${customerId}`, toBackendCustomer(data)).then(normalizeCustomer);
export const deleteCustomer = (customerId) => del(`/customers/${customerId}`);
