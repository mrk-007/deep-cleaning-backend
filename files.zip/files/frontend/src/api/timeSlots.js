import { get, post, put, del } from "../utils/api.js";

export const listTimeSlots = () => get("/time-slots");
export const getTimeSlot = (slotId) => get(`/time-slots/${slotId}`);
export const createTimeSlot = (data) => post("/time-slots", data);
export const updateTimeSlot = (slotId, data) => put(`/time-slots/${slotId}`, data);
export const deleteTimeSlot = (slotId) => del(`/time-slots/${slotId}`);

export const getAvailableSlots = (params = {}) => {
  const query = new URLSearchParams(params).toString();
  return get(`/time-slots/availability?${query}`);
};
