import { get, post, put, del } from "../utils/api.js";

export const listPaymentAccounts = (activeStatusId = "") =>
  get(
    activeStatusId
      ? `/payment-accounts?activeStatusId=${encodeURIComponent(activeStatusId)}`
      : "/payment-accounts",
  );
export const getPaymentAccount = (accountId) =>
  get(`/payment-accounts/${accountId}`);
export const createPaymentAccount = (data) => post("/payment-accounts", data);
export const updatePaymentAccount = (accountId, data) =>
  put(`/payment-accounts/${accountId}`, data);
export const deletePaymentAccount = (accountId) =>
  del(`/payment-accounts/${accountId}`);
