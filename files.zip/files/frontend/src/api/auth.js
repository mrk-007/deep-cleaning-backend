import { get, post } from "../utils/api.js";

const normalizeUser = (user) => ({
	...user,
	name: user?.name ?? user?.userName,
	role: user?.role ?? user?.roleId?.roleName,
});

export const getCurrentUser = async () => normalizeUser(await get("/users/me"));

export const login = async (email, password) => {
	const data = await post("/login", { email, password });
	const token = data?.token ?? data?.accessToken;
	if (token) localStorage.setItem("token", token);
	return { ...data, user: normalizeUser(data?.user ?? data) };
};

export const logout = () => {
	localStorage.removeItem("token");
};
