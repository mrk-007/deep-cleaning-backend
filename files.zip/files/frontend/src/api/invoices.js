import { get, post, del } from "../utils/api.js";

const normalizeInvoice = (invoice) => {
	if (!invoice) return invoice;
	const customerId =
		invoice.customerId?._id ?? invoice.customerId ??
		invoice.customerReference?._id ?? invoice.customerReference;
	const bookingId =
		invoice.bookingId?._id ?? invoice.bookingId ??
		invoice.bookingReference?._id ?? invoice.bookingReference;
	const createdDate = invoice.createdDate ?? invoice.createdAt?.slice(0, 10);

	return {
		...invoice,
		id: invoice.id ?? invoice._id ?? invoice.invoiceNumber,
		invoiceNumber: invoice.invoiceNumber ?? invoice.id,
		customerId,
		bookingId,
		bookingIds: invoice.bookingIds ?? (bookingId ? [bookingId] : []),
		status: invoice.status ?? (invoice.isCancelled ? "cancelled" : invoice.isCompleted ? "paid" : "pending"),
		createdDate,
		paidDate: invoice.paidDate ?? createdDate,
	};
};

export const listInvoices = async (filters = {}) => {
	const params = new URLSearchParams(
		Object.entries(filters).filter(([, value]) => value !== undefined && value !== ""),
	).toString();
	const invoices = await get(params ? `/invoices?${params}` : "/invoices");
	return invoices.map(normalizeInvoice);
};
export const getInvoice = async (invoiceId) =>
	normalizeInvoice(await get(`/invoices/${invoiceId}`));
export const getInvoiceByBooking = async (bookingId) =>
	normalizeInvoice(await get(`/invoices/booking/${bookingId}`));
export const createInvoice = (data) => post("/invoices", data);
export const deleteInvoice = (invoiceId) => del(`/invoices/${invoiceId}`);
