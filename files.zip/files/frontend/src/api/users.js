import { get, post, put, del } from "../utils/api.js";

export const listUsers = () => get("/users");
export const getUser = (userId) => get(`/users/${userId}`);
export const createUser = (data) => post("/users", data);
export const updateUser = (userId, data) => put(`/users/${userId}`, data);
export const deleteUser = (userId) => del(`/users/${userId}`);
