import { get, post, put, del } from "../utils/api.js";

export const listPermissions = () => get("/permissions");
export const getPermission = (permissionId) => get(`/permissions/${permissionId}`);
export const createPermission = (data) => post("/permissions", data);
export const updatePermission = (permissionId, data) =>
  put(`/permissions/${permissionId}`, data);
export const deletePermission = (permissionId) =>
  del(`/permissions/${permissionId}`);
