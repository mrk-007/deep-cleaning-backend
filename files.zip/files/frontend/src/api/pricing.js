import { get, post, put, del } from "../utils/api.js";

export const listPricing = (isActive) => {
  const query = isActive === undefined ? "" : `?isActive=${isActive}`;
  return get(`/pricing${query}`);
};
export const getPricing = (pricingId) => get(`/pricing/${pricingId}`);
export const createPricing = (data) => post("/pricing", data);
export const updatePricing = (pricingId, data) =>
  put(`/pricing/${pricingId}`, data);
export const deletePricing = (pricingId) => del(`/pricing/${pricingId}`);
