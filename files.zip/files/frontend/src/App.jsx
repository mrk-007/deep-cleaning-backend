import { useState, useEffect, useMemo } from "react";
import { ThemeProvider } from "@mui/material/styles";
import Box from "@mui/material/Box";

import { buildTheme } from "./theme.js";
import { getCurrentUser, login, logout } from "./api/auth.js";
import GlobalPrintStyle from "./components/common-components/GlobalPrintStyle.jsx";
import FullPageSpinner from "./components/common-components/FullPageSpinner.jsx";
import AuthPage from "./pages/AuthPage.jsx";
import Workspace from "./components/Workspace.jsx";

export default function App() {
  const [mode, setMode] = useState("light");
  const [currentUser, setCurrentUser] = useState(null);
  const [checkingSession, setCheckingSession] = useState(true);
  const theme = useMemo(() => buildTheme(mode), [mode]);

  useEffect(() => {
    let active = true;
    getCurrentUser()
      .then((user) => {
        if (active) setCurrentUser(user);
      })
      .catch(() => {
        if (active) setCurrentUser(null);
      })
      .finally(() => {
        if (active) setCheckingSession(false);
      });
    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    if (checkingSession) return;
    const nextPath = currentUser ? "/dashboard" : "/login";
    if (window.location.pathname !== nextPath) {
      window.history.replaceState({}, "", nextPath);
    }
  }, [checkingSession, currentUser]);

  const logIn = async (email, password) => {
    const data = await login(email, password);
    const user = data?.user ?? data;
    if (!user || typeof user !== "object") {
      throw new Error("Login succeeded, but the user session was not returned.");
    }
    setCurrentUser(user);
  };

  const logOut = async () => {
    try {
      await logout();
    } finally {
      setCurrentUser(null);
    }
  };

  return (
    <ThemeProvider theme={theme}>
      <GlobalPrintStyle />
      <Box
        sx={{
          bgcolor: "background.default",
          color: "text.primary",
          minHeight: "100vh",
        }}
      >
        {checkingSession ? (
          <FullPageSpinner />
        ) : !currentUser ? (
          <AuthPage onLogIn={logIn} />
        ) : (
          <Workspace
            currentUser={currentUser}
            onLogout={logOut}
            mode={mode}
            setMode={setMode}
          />
        )}
      </Box>
    </ThemeProvider>
  );
}
