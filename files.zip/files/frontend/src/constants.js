// ============================================================================
// EDIT THIS FILE to change core business rules.
// ============================================================================

// Minutes required per visit, keyed by bathroom count (1–4).
export const DURATION_BY_BATHROOMS = { 1: 30, 2: 45, 3: 60, 4: 75};

// Minutes kept free between the end of one job and the start of the next.
// Service working window, in minutes from midnight.
export const DAY_START_MIN = 8 * 60 + 30; // 8:30 AM
export const DAY_END_MIN = 18 * 60 + 30; // 6:30 PM

// Starting price per visit by bathroom count (editable live in Settings too).
export const DEFAULT_PRICING = { 1: 300, 2: 500, 3: 500, 4: 700 };

// Brand colors — used by src/theme.js. Change these to rebrand the app.
export const BRAND = {
  green: "#178A72",
  greenDark: "#0E6B57",
  orange: "#F2994A",
  black: "#141414",
};
