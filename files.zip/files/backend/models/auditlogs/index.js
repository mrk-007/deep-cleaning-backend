const UserLog = require('./userLog');
const RoleLog = require('./roleLog');
const CustomerLog = require('./customerLog');
const BookingLog = require('./bookingLog');
const SubscriptionLog = require('./subscriptionLog');
const SubscriptionTypeLog = require('./subscriptionTypeLog');
const ServicePaymentLog = require('./servicePaymentLog');

module.exports = {
  UserLog,
  RoleLog,
  CustomerLog,
  BookingLog,
  SubscriptionLog,
  SubscriptionTypeLog,
  ServicePaymentLog,
};
