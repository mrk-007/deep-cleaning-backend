# Jolly Home Needs - Revised Database Architecture

## 1. Naming and design standards

- Node.js / Mongoose model names use singular PascalCase: `SubscriptionType`, `Subscription`, `ServicePayment`.
- JavaScript fields use camelCase: `subscriptionTypeReference`, `isCompleted`.
- MongoDB collections use plural camelCase through the existing Mongoose naming convention.
- API routes use plural kebab-case: `/api/subscription-types`, `/api/subscriptions`, `/api/service-payments`.
- All relationships store MongoDB `ObjectId` values. Business IDs such as `BKG-001`, `SUB-001`, `VIS-001`, and `SPY-001` are display/search identifiers only.
- `SubscriptionType` is master data. `Subscription` is the actual customer transaction. They must never share a model, collection, controller, validator, or route.

## 2. Removed collections and references

- Remove `ActiveStatus` and every `activeStatusReference`. Use `isActive: Boolean` with default `true` on master, security, and operational collections.
- Remove `Permission` and every `permissionReferences` field and route.
- Remove `WorkStatus` because booking, subscription, visit, invoice, and service-payment lifecycle state is stored directly in each transaction document.
- Immutable audit/log records and `Counter` do not use `isActive` because they are not enabled/disabled business records.

## 3. Role authorization

`Role` stores direct capability flags:

| Role | canRead | canWrite | canUpdate | canDelete |
|---|---:|---:|---:|---:|
| superadmin | true | true | true | true |
| admin | true | true | false | false |
| user | true | false | false | false |

The authorization middleware reads the authenticated user's `roleReference` and checks the required capability.

## 4. Lifecycle boolean rule

Transaction collections use:

- `isPending`
- `isCompleted`
- `isCancelled`

Exactly one lifecycle flag must be `true` at a time. New records default to `isPending: true`, `isCompleted: false`, and `isCancelled: false`. Controllers must update the flags atomically and validators must reject conflicting combinations.

## 5. Complete Mermaid ER diagram

```mermaid
erDiagram
    ROLE ||--o{ USER : roleReference
    USER ||--o{ BOOKING_DATE : createdBy
    USER ||--o{ BOOKING : createdBy
    USER ||--o{ INVOICE : createdBy
    USER ||--o{ SUBSCRIPTION : createdBy
    USER ||--o{ VISIT : createdBy
    USER ||--o{ VISIT : updatedBy
    USER ||--o{ SERVICE_PAYMENT : createdBy

    CUSTOMER ||--o{ BOOKING : customerReference
    CUSTOMER ||--o{ INVOICE : customerReference
    CUSTOMER ||--o{ SUBSCRIPTION : customerReference
    CUSTOMER ||--o{ VISIT : customerReference
    CUSTOMER ||--o{ SERVICE_PAYMENT : customerReference

    SERVICE_DURATION ||--o{ PRICING : serviceDurationReference
    BATHROOM_COUNT ||--o{ PRICING : bathroomCountReference

    CUSTOMER ||--o{ BOOKING : customerReference
    BATHROOM_COUNT ||--o{ BOOKING : bathroomCountReference
    PRICING ||--o{ BOOKING : pricingReference
    SERVICE_DURATION ||--o{ BOOKING : serviceDurationReference
    SERVICE_FREQUENCY ||--o{ BOOKING : serviceFrequencyReference
    SUBSCRIPTION_TYPE ||--o{ BOOKING : subscriptionTypeReference
    TIME_SLOT ||--o{ BOOKING : timeSlotReference
    BOOKING_DATE ||--o{ BOOKING : bookingDateReference
    PAYMENT_METHOD ||--o{ BOOKING : paymentMethodReference
    PAYMENT_ACCOUNT ||--o{ BOOKING : paymentAccountReference

    BOOKING ||--o| INVOICE : bookingReference
    BOOKING ||--o| SUBSCRIPTION : bookingReference
    BOOKING ||--o| SERVICE_PAYMENT : bookingReference

    PRICING ||--o{ SUBSCRIPTION : pricingReference
    SERVICE_FREQUENCY ||--o{ SUBSCRIPTION : serviceFrequencyReference
    SUBSCRIPTION_TYPE ||--o{ SUBSCRIPTION : subscriptionTypeReference

    SUBSCRIPTION ||--o{ VISIT : subscriptionReference
    BOOKING ||--o{ VISIT : bookingReference
    TIME_SLOT ||--o{ VISIT : timeSlotReference

    PRICING ||--o{ SERVICE_PAYMENT : pricingReference
    PAYMENT_MASTER ||--o{ SERVICE_PAYMENT : paymentMasterReference
    SUBSCRIPTION ||--o| SERVICE_PAYMENT : subscriptionReference
    PAYMENT_METHOD ||--o{ SERVICE_PAYMENT : paymentMethodReference
    PAYMENT_ACCOUNT ||--o{ SERVICE_PAYMENT : paymentAccountReference

    ROLE {
        ObjectId _id PK
        string roleName UK
        boolean canRead
        boolean canWrite
        boolean canUpdate
        boolean canDelete
        boolean isActive
    }
    USER {
        ObjectId _id PK
        string userName
        string email UK
        string passwordHash
        ObjectId roleReference FK
        boolean isActive
    }
    CUSTOMER {
        ObjectId _id PK
        string name
        string phoneNumber UK
        string address
        string doorNo
        string block
        string apartmentName
        string landmark
        string city
        string pincode
        boolean isActive
    }
    BATHROOM_COUNT {
        ObjectId _id PK
        number bathroomCount UK
        boolean isActive
    }
    SERVICE_DURATION {
        ObjectId _id PK
        number durationMinutes UK
        boolean isActive
    }
    SERVICE_FREQUENCY {
        ObjectId _id PK
        string frequencyName UK
        number intervalDays
        boolean isActive
    }
    SUBSCRIPTION_TYPE {
        ObjectId _id PK
        string subscriptionTypeName UK
        number totalServiceVisits
        number validityDays
        boolean isActive
    }
    TIME_SLOT {
        ObjectId _id PK
        string startTime
        string endTime
        number bufferTime
        boolean isActive
    }
    PAYMENT_METHOD {
        ObjectId _id PK
        string paymentMethodName UK
        boolean isActive
    }
    PAYMENT_ACCOUNT {
        ObjectId _id PK
        string accountName UK
        boolean isActive
    }
    PAYMENT_MASTER {
        ObjectId _id PK
        number cgstRate
        number sgstRate
        number discountRate
        date effectiveFrom
        date effectiveTo
        boolean isActive
    }
    PRICING {
        ObjectId _id PK
        ObjectId serviceDurationReference FK
        ObjectId bathroomCountReference FK
        number price
        date effectiveFrom
        date effectiveTo
        boolean isActive
    }
    BOOKING_DATE {
        ObjectId _id PK
        date startDateTime
        date endDateTime
        ObjectId createdBy FK
        boolean isActive
    }
    BOOKING {
        ObjectId _id PK
        string bookingId UK
        ObjectId customerReference FK
        ObjectId bathroomCountReference FK
        ObjectId pricingReference FK
        ObjectId serviceDurationReference FK
        ObjectId serviceFrequencyReference FK
        ObjectId subscriptionTypeReference FK
        ObjectId timeSlotReference FK
        ObjectId bookingDateReference FK
        ObjectId paymentMethodReference FK
        ObjectId paymentAccountReference FK
        ObjectId createdBy FK
        string transactionId
        number amount
        boolean isPending
        boolean isCompleted
        boolean isCancelled
        boolean isActive
    }
    SUBSCRIPTION {
        ObjectId _id PK
        string subscriptionId UK
        ObjectId bookingReference FK_UK
        ObjectId customerReference FK
        ObjectId pricingReference FK
        ObjectId serviceFrequencyReference FK
        ObjectId subscriptionTypeReference FK
        ObjectId createdBy FK
        date startDate
        date endDate
        number totalVisits
        number completedVisits
        number remainingVisits
        number scheduleIntervalDays
        boolean isPending
        boolean isCompleted
        boolean isCancelled
        boolean isActive
    }
    VISIT {
        ObjectId _id PK
        string visitId UK
        ObjectId subscriptionReference FK
        ObjectId bookingReference FK
        ObjectId customerReference FK
        ObjectId timeSlotReference FK
        ObjectId createdBy FK
        ObjectId updatedBy FK
        number visitNumber CUK
        date scheduledStartDateTime
        date scheduledEndDateTime
        date actualStartDateTime
        date actualEndDateTime
        boolean isPending
        boolean isCompleted
        boolean isCancelled
        string remarks
        boolean isActive
    }
    SERVICE_PAYMENT {
        ObjectId _id PK
        string servicePaymentId UK
        ObjectId bookingReference FK_UK
        ObjectId subscriptionReference FK
        ObjectId customerReference FK
        ObjectId pricingReference FK
        ObjectId paymentMasterReference FK
        ObjectId paymentMethodReference FK
        ObjectId paymentAccountReference FK
        ObjectId createdBy FK
        number pricePerVisit
        number totalServiceVisits
        number baseAmount
        number cgstRate
        number cgstAmount
        number sgstRate
        number sgstAmount
        number discountRate
        number discountAmount
        number totalAmount
        string transactionId
        boolean isPending
        boolean isCompleted
        boolean isCancelled
        boolean isActive
    }
    INVOICE {
        ObjectId _id PK
        string invoiceNumber UK
        ObjectId customerReference FK
        ObjectId bookingReference FK_UK
        ObjectId servicePaymentReference FK
        ObjectId createdBy FK
        number amount
        boolean isPending
        boolean isCompleted
        boolean isCancelled
        boolean isActive
    }
    COUNTER {
        string _id PK
        number seq
    }
```

## 6. Payment calculation

`ServicePayment` reads active master records and stores immutable snapshots of the values used for calculation.

```text
pricePerVisit = Pricing.price
baseAmount = pricePerVisit * totalServiceVisits
discountAmount = baseAmount * discountRate / 100
taxableAmount = baseAmount - discountAmount
cgstAmount = taxableAmount * cgstRate / 100
sgstAmount = taxableAmount * sgstRate / 100
totalAmount = taxableAmount + cgstAmount + sgstAmount
```

Do not recalculate old payments when `PaymentMaster` or `Pricing` changes. Historical `ServicePayment` documents retain their rate and amount snapshots.

## 7. Core workflow

1. Load only records where `isActive: true` from all selectable master collections.
2. Create `BKG-xxx` with only ObjectId references.
3. Read `SubscriptionType.totalServiceVisits` and `ServiceFrequency.intervalDays`.
4. Create exactly one `SUB-xxx` for the eligible booking.
5. Generate `VIS-xxx` records with a unique compound index on `subscriptionReference + visitNumber`.
6. Create one `SPY-xxx` ServicePayment per booking.
7. Read `Pricing.price`, active `PaymentMaster` rates, and total service visit count.
8. Calculate and snapshot base amount, discount, CGST, SGST, and total payable amount.
9. Generate the invoice from `ServicePayment.totalAmount`.
10. Perform booking, subscription, visits, service payment, invoice, counters, and logs in one MongoDB transaction.

## 8. Required indexes

- `Role.roleName`: unique
- `User.email`: unique
- `Booking.bookingId`: unique
- `Subscription.subscriptionId`: unique
- `Subscription.bookingReference`: unique
- `Visit.visitId`: unique
- `Visit.subscriptionReference + visitNumber`: compound unique
- `ServicePayment.servicePaymentId`: unique
- `ServicePayment.bookingReference`: unique
- `Invoice.invoiceNumber`: unique
- `Invoice.bookingReference`: unique
- Active payment master lookup: `{ isActive: 1, effectiveFrom: -1 }`

## 9. Route separation

- `/api/subscription-types`: Subscription Type master CRUD
- `/api/subscriptions`: actual customer Subscription transactions
- `/api/payment-masters`: CGST, SGST, and discount configuration
- `/api/service-payments`: calculated customer service payments
- `/api/payment-methods`: payment method master
- `/api/payment-accounts`: receiving account master

## 10. Migration checklist

1. Add `isActive: true` to existing master, security, customer, and operational documents.
2. Replace every `activeStatusReference` query and validation with `isActive`.
3. Remove `ActiveStatus` model, controller, validator, routes, seeds, and frontend calls after data migration.
4. Add role capability booleans and migrate roles using the capability matrix.
5. Remove `Permission` model, collection, references, routes, validators, seeds, and frontend calls.
6. Remove `WorkStatus` references after adding lifecycle booleans to transaction schemas and migrating existing status values.
7. Create `PaymentMaster` and seed effective CGST, SGST, and discount rates.
8. Create `ServicePayment` and calculate totals only on the server.
9. Add lifecycle invariant validation so exactly one of `isPending`, `isCompleted`, or `isCancelled` is true.
10. Preserve the current project structure and update only existing models, controllers, routes, validators, middleware, seeds, logs, and API calls required for this redesign.

## 11. Simple backend redesign prompt

```text
Read @artifacts.md, @DC_ER_Tables_Revised.xlsx, and the complete backend before changing anything. Follow the existing Node.js/Mongoose naming conventions, file names, folder structure, schema field order, controllers, routes, validators, middleware, response format, error handling, logs, and import/export style.

Replace ActiveStatus references with `isActive: true`, remove the Permission module, and store `canRead`, `canWrite`, `canUpdate`, and `canDelete` directly in Role using the documented superadmin/admin/user matrix. Keep `/api/subscription-types` for SubscriptionType master data and `/api/subscriptions` for actual Subscription transactions; never merge or rename them.

Add PaymentMaster for CGST, SGST, and discount rates, and ServicePayment for server-side payment calculation using Pricing, total service visits, and immutable rate/amount snapshots. Add `isPending`, `isCompleted`, and `isCancelled` to Booking, Subscription, Visit, ServicePayment, and Invoice, enforcing exactly one true lifecycle state. Implement BKG -> SUB -> VIS -> ServicePayment -> Invoice with ObjectId references, existing counters, uniqueness rules, logs, and one MongoDB transaction.

Do not create conflicting names, duplicate routes, unnecessary aliases, services, helpers, folders, or abstractions. Preserve all unrelated functionality and return the modified-file list with a short explanation for each change.
```
