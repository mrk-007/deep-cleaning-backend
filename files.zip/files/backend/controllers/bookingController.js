const mongoose = require('mongoose');

const Booking = require('../models/Booking');
const Invoice = require('../models/invoice');
const Counter = require('../models/counter');
const TimeSlot = require('../models/timeSlot');
const ServiceDuration = require('../models/serviceDuration');
const ServiceFrequency = require('../models/serviceFrequency');
const Pricing = require('../models/pricing');
const PaymentAccount = require('../models/paymentAccount');
const PaymentMaster = require('../models/paymentMaster');
const ServicePayment = require('../models/servicePayment');
const SubscriptionType = require('../models/subscriptionType');
const Subscription = require('../models/subscription');
const Visit = require('../models/visit');
const BookingLog = require('../models/auditlogs/bookingLog');
const ServicePaymentLog = require('../models/auditlogs/servicePaymentLog');

// Helper to format date as YYYYMMDD
const getDateKey = (date = new Date()) => {
  const yyyy = date.getUTCFullYear();
  const mm = String(date.getUTCMonth() + 1).padStart(2, '0');
  const dd = String(date.getUTCDate()).padStart(2, '0');

  return `${yyyy}${mm}${dd}`;
};

// Helper to parse 12-hour or 24-hour time into minutes
const parseTimeToMinutes = (timeStr) => {
  if (!timeStr || typeof timeStr !== 'string') {
    return null;
  }

  const cleaned = timeStr.trim().toUpperCase();
  const is12Hour = cleaned.includes('AM') || cleaned.includes('PM');

  if (is12Hour) {
    const isPM = cleaned.includes('PM');
    const timePart = cleaned.replace(/AM|PM/g, '').trim();
    const [hoursStr, minutesStr = '0'] = timePart.split(':');

    let hours = Number.parseInt(hoursStr, 10);
    const minutes = Number.parseInt(minutesStr, 10);

    if (
      Number.isNaN(hours) ||
      Number.isNaN(minutes) ||
      hours < 1 ||
      hours > 12 ||
      minutes < 0 ||
      minutes > 59
    ) {
      return null;
    }

    if (isPM && hours !== 12) {
      hours += 12;
    }

    if (!isPM && hours === 12) {
      hours = 0;
    }

    return hours * 60 + minutes;
  }

  const [hoursStr, minutesStr = '0'] = cleaned.split(':');

  const hours = Number.parseInt(hoursStr, 10);
  const minutes = Number.parseInt(minutesStr, 10);

  if (
    Number.isNaN(hours) ||
    Number.isNaN(minutes) ||
    hours < 0 ||
    hours > 23 ||
    minutes < 0 ||
    minutes > 59
  ) {
    return null;
  }

  return hours * 60 + minutes;
};

// Helper to combine YYYY-MM-DD date with minutes from midnight
const combineDateAndTime = (scheduledDate, totalMinutes) => {
  const dateValue = String(scheduledDate).trim();

  if (!/^\d{4}-\d{2}-\d{2}$/.test(dateValue)) {
    return null;
  }

  const [year, month, day] = dateValue
    .split('-')
    .map((value) => Number(value));

  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;

  const combinedDate = new Date(
    Date.UTC(year, month - 1, day, hours, minutes, 0, 0)
  );

  if (Number.isNaN(combinedDate.getTime())) {
    return null;
  }

  return combinedDate;
};

// Add calendar months without allowing dates such as January 31 to overflow
// into a later month.
const addCalendarMonths = (date, months) => {
  const result = new Date(date);
  const originalDay = result.getUTCDate();

  result.setUTCDate(1);
  result.setUTCMonth(result.getUTCMonth() + months);

  const lastDayOfTargetMonth = new Date(
    Date.UTC(result.getUTCFullYear(), result.getUTCMonth() + 1, 0)
  ).getUTCDate();
  result.setUTCDate(Math.min(originalDay, lastDayOfTargetMonth));

  return result;
};

// Helper to convert subscription type timeGap values such as "7", "7days", and "7 days" into days
const parseTimeGapToDays = (timeGap) => {
  if (timeGap === null || timeGap === undefined || timeGap === '') {
    return null;
  }

  const normalizedTimeGap = String(timeGap).trim();

  if (!normalizedTimeGap) {
    return null;
  }

  const directNumberValue = Number(normalizedTimeGap);
  if (Number.isInteger(directNumberValue) && directNumberValue > 0) {
    return directNumberValue;
  }

  const match = normalizedTimeGap.match(/^(\d+)\s*(?:day|days)?$/i);

  if (!match) {
    return null;
  }

  const intervalDays = Number(match[1]);
  return intervalDays > 0 ? intervalDays : null;
};

const getFrequencyIntervalDays = (frequencyName, configuredIntervalDays) => {
  const normalizedName = String(frequencyName || '').toLowerCase().replace(/[^a-z0-9]/g, '');
  if (
    normalizedName.includes('biweekly') ||
    normalizedName.includes('every2weeks') ||
    normalizedName.includes('2weeks')
  ) {
    return 14;
  }
  if (
    normalizedName.includes('weekly') ||
    normalizedName.includes('everyweek') ||
    normalizedName.includes('onceaweek') ||
    normalizedName.includes('perweek')
  ) {
    return 7;
  }
  return Number(configuredIntervalDays);
};

// Helper to get the authenticated user's MongoDB ObjectId
const getUserObjectId = (req) => {
  if (!req.user) {
    return null;
  }

  const userId = req.user._id || req.user.id || req.user.userId || null;

  if (!userId || !mongoose.Types.ObjectId.isValid(userId)) {
    return null;
  }

  return userId;
};

// Helper to populate booking references
const populateBookingReferences = (query) => {
  return query
    .populate('customerReference')
    .populate('bathroomCountReference')
    .populate('pricingReference')
    .populate('serviceDurationReference')
    .populate('serviceFrequencyReference')
    .populate('subscriptionTypeReference')
    .populate('timeSlotReference')
    .populate('paymentMethodReference')
    .populate('paymentAccountReference');
};

// Get all bookings with optional filters
exports.getAllBookings = async (req, res) => {
  try {
    const {
      customerId,
      isPending,
      isCompleted,
      isCancelled,
      startDate,
      endDate,
    } = req.query;

    const filter = {};

    if (customerId) {
      filter.customerReference = customerId;
    }

    if (isPending !== undefined) {
      filter.isPending = isPending === true || isPending === 'true';
    }

    if (isCompleted !== undefined) {
      filter.isCompleted = isCompleted === true || isCompleted === 'true';
    }

    if (isCancelled !== undefined) {
      filter.isCancelled = isCancelled === true || isCancelled === 'true';
    }

    if (startDate || endDate) {
      filter.startDateTime = {};

      if (startDate) {
        filter.startDateTime.$gte = new Date(
          `${startDate}T00:00:00.000Z`
        );
      }

      if (endDate) {
        filter.startDateTime.$lte = new Date(
          `${endDate}T23:59:59.999Z`
        );
      }
    }

    const bookings = await populateBookingReferences(
      Booking.find(filter)
    ).sort({ startDateTime: -1 });

    const recurringBookings = bookings.filter((booking) => booking.subscriptionTypeReference);
    const visitFilter = recurringBookings.length
      ? { bookingReference: { $in: recurringBookings.map((booking) => booking._id) } }
      : { bookingReference: { $in: [] } };
    const visits = await Visit.find(visitFilter).sort({ scheduledStartDateTime: -1 }).lean();
    const bookingById = new Map(
      recurringBookings.map((booking) => [String(booking._id), booking.toObject()]),
    );
    const visitBookings = visits.map((visit) => {
      const parentBooking = bookingById.get(String(visit.bookingReference));
      return {
        ...parentBooking,
        _id: visit._id,
        bookingId: visit.bookingReference,
        visitId: visit.visitId,
        subscriptionReference: visit.subscriptionReference,
        bookingReference: visit.bookingReference,
        scheduledDate: visit.scheduledStartDateTime,
        startDateTime: visit.scheduledStartDateTime,
        endDateTime: visit.scheduledEndDateTime,
        status: visit.isCancelled
          ? 'Cancelled'
          : visit.isCompleted
            ? 'Completed'
            : 'Scheduled',
        isVisit: true,
      };
    });
    const oneTimeBookings = bookings.filter((booking) => !booking.subscriptionTypeReference);

    res.status(200).json([...oneTimeBookings, ...visitBookings]);
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

// Get a single booking by MongoDB ObjectId
exports.getBookingById = async (req, res) => {
  try {
    if (!mongoose.Types.ObjectId.isValid(req.params.id)) {
      return res.status(400).json({
        message: 'Invalid booking ID',
      });
    }

    const booking = await populateBookingReferences(
      Booking.findById(req.params.id)
    );

    if (!booking) {
      return res.status(404).json({
        message: 'Booking not found',
      });
    }

    const invoice = await Invoice.findOne({
      bookingReference: booking._id,
    });

    res.status(200).json({
      booking,
      invoice,
    });
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

const roundCurrency = (value) => Math.round((value + Number.EPSILON) * 100) / 100;

// Create a booking and all related operational records atomically.
exports.createBooking = async (req, res) => {
  try {
    const {
      customerId,
      bathroomCountId,
      pricingId,
      serviceDurationId,
      serviceFrequencyId,
      subscriptionTypeId,
      timeSlotId,
      scheduledDate,
      startTime,
      paymentMethodId,
      paymentAccountId,
      transactionId,
    } = req.body;

    if (!customerId) {
      return res.status(400).json({
        message: 'customerId is required',
      });
    }

    if (!scheduledDate) {
      return res.status(400).json({
        message: 'scheduledDate is required',
      });
    }

    if (!timeSlotId) {
      return res.status(400).json({
        message: 'timeSlotId is required',
      });
    }

    if (!pricingId) {
      return res.status(400).json({
        message: 'pricingId is required',
      });
    }

    if (!mongoose.Types.ObjectId.isValid(customerId)) {
      return res.status(400).json({
        message: 'Invalid customerId',
      });
    }

    if (!mongoose.Types.ObjectId.isValid(timeSlotId)) {
      return res.status(400).json({
        message: 'Invalid timeSlotId',
      });
    }

    if (
      paymentAccountId !== undefined &&
      paymentAccountId !== null &&
      !mongoose.Types.ObjectId.isValid(paymentAccountId)
    ) {
      return res.status(400).json({
        message: 'Invalid paymentAccountId',
      });
    }

    if (!/^\d{4}-\d{2}-\d{2}$/.test(String(scheduledDate))) {
      return res.status(400).json({
        message: 'scheduledDate must use YYYY-MM-DD format',
      });
    }

    const selectedTimeSlot = await TimeSlot.findById(timeSlotId);

    if (!selectedTimeSlot) {
      return res.status(404).json({
        message: 'Selected time slot not found',
      });
    }

    const slotStartMinutes = parseTimeToMinutes(
      startTime || selectedTimeSlot.startTime
    );

    if (slotStartMinutes === null) {
      return res.status(400).json({
        message: 'Selected time slot contains an invalid startTime',
      });
    }

    let resolvedServiceDuration = null;

    if (serviceDurationId) {
      if (!mongoose.Types.ObjectId.isValid(serviceDurationId)) {
        return res.status(400).json({
          message: 'Invalid serviceDurationId',
        });
      }

      const serviceDuration = await ServiceDuration.findById(
        serviceDurationId
      );

      if (!serviceDuration) {
        return res.status(404).json({
          message: 'Service duration not found',
        });
      }

      resolvedServiceDuration = Number(
        serviceDuration.durationMinutes
      );
    }

    let selectedPricing = null;
    if (pricingId) {
      if (!mongoose.Types.ObjectId.isValid(pricingId)) {
        return res.status(400).json({
          message: 'Invalid pricingId',
        });
      }

      selectedPricing = await Pricing.findOne({ _id: pricingId, isActive: true }).populate(
        'serviceDurationReference'
      );

      if (
        selectedPricing &&
        selectedPricing.serviceDurationReference &&
        selectedPricing.serviceDurationReference.durationMinutes !== undefined
      ) {
        resolvedServiceDuration = Number(
          selectedPricing.serviceDurationReference.durationMinutes
        );
      }
    }

    if (pricingId && !selectedPricing) {
      return res.status(404).json({ message: 'Pricing record not found' });
    }

    if (
      !resolvedServiceDuration ||
      resolvedServiceDuration <= 0
    ) {
      return res.status(400).json({
        message:
          'Unable to determine service duration from serviceDurationId or pricingId',
      });
    }

    const resolvedBufferTime =
      Number(selectedTimeSlot.bufferTime) || 0;

    const totalDuration =
      resolvedServiceDuration + resolvedBufferTime;

    const calculatedStartDateTime = combineDateAndTime(
      scheduledDate,
      slotStartMinutes
    );

    const calculatedEndDateTime = combineDateAndTime(
      scheduledDate,
      slotStartMinutes + totalDuration
    );

    if (
      !calculatedStartDateTime ||
      !calculatedEndDateTime
    ) {
      return res.status(400).json({
        message:
          'Unable to calculate booking startDateTime and endDateTime',
      });
    }

    const normalizedScheduledDate = new Date(
      `${scheduledDate}T00:00:00.000Z`
    );

    const existingBookings = await Booking.find({
      startDateTime: {
        $lt: calculatedEndDateTime,
      },
      endDateTime: {
        $gt: calculatedStartDateTime,
      },
    });

    const existingVisits = await Visit.find({
      scheduledStartDateTime: {
        $lt: calculatedEndDateTime,
      },
      scheduledEndDateTime: {
        $gt: calculatedStartDateTime,
      },
      isCancelled: { $ne: true },
    });

    const conflictingBooking = existingBookings.find(
      (existingBooking) => {
        return !existingBooking.isCancelled;
      }
    );

    if (conflictingBooking || existingVisits.length > 0) {
      return res.status(409).json({
        message:
          'The selected date and time slot is already booked. Please choose another slot.',
      });
    }

    const shouldCreateSubscription = subscriptionTypeId !== undefined && subscriptionTypeId !== null;
    let normalizedTotalVisits = 1;
    let subscriptionType = null;
    let scheduleIntervalDays = null;
    let serviceFrequency = null;
    let subscriptionEndDate = null;
    let visitScheduleDates = [];
    if (shouldCreateSubscription) {
      if (!pricingId || !serviceFrequencyId) {
        return res.status(400).json({
          message: 'pricingId and serviceFrequencyId are required for a subscription booking',
        });
      }

      if (!mongoose.Types.ObjectId.isValid(subscriptionTypeId)) {
        return res.status(400).json({ message: 'Invalid subscriptionTypeId' });
      }

      if (!mongoose.Types.ObjectId.isValid(serviceFrequencyId)) {
        return res.status(400).json({ message: 'Invalid serviceFrequencyId' });
      }

      subscriptionType = await SubscriptionType.findOne({
        _id: subscriptionTypeId,
        isActive: true,
      });

      if (!subscriptionType) {
        return res.status(404).json({ message: 'Subscription type not found' });
      }

      serviceFrequency = await ServiceFrequency.findOne({
        _id: serviceFrequencyId,
        isActive: true,
      });
      if (!serviceFrequency) {
        return res.status(404).json({ message: 'Service frequency not found' });
      }

      scheduleIntervalDays = Number(serviceFrequency.intervalDays);
      const subscriptionDurationMonths = Number(subscriptionType.timeGap);
      if (!Number.isInteger(scheduleIntervalDays) || scheduleIntervalDays < 1 ||
          !Number.isInteger(subscriptionDurationMonths) || subscriptionDurationMonths < 1) {
        return res.status(400).json({
          message: 'Subscription type timeGap must be positive whole months and service frequency intervalDays must be a positive whole number',
        });
      }

      subscriptionEndDate = addCalendarMonths(
        calculatedStartDateTime,
        subscriptionDurationMonths,
      );

      const visitDuration = calculatedEndDateTime.getTime() - calculatedStartDateTime.getTime();
      let scheduledStartDateTime = new Date(calculatedStartDateTime);
      while (scheduledStartDateTime <= subscriptionEndDate) {
        visitScheduleDates.push({
          scheduledStartDateTime: new Date(scheduledStartDateTime),
          scheduledEndDateTime: new Date(scheduledStartDateTime.getTime() + visitDuration),
        });

        const nextScheduledStartDateTime = new Date(scheduledStartDateTime);
        nextScheduledStartDateTime.setUTCDate(
          nextScheduledStartDateTime.getUTCDate() + scheduleIntervalDays,
        );

        if (nextScheduledStartDateTime > subscriptionEndDate) {
          break;
        }

        scheduledStartDateTime = nextScheduledStartDateTime;
      }

      normalizedTotalVisits = visitScheduleDates.length;
    }

    const userId = getUserObjectId(req);
    let savedBooking = null;
    let savedPayment = null;
    let savedInvoice = null;
    let savedSubscription = null;
    let savedVisits = [];
    const session = await mongoose.startSession();

    try {
      await session.withTransaction(async () => {
        const paymentMaster = await PaymentMaster.findOne({
          isActive: true,
          effectiveFrom: { $lte: new Date() },
          $or: [{ effectiveTo: null }, { effectiveTo: { $gte: new Date() } }],
        }).sort({ effectiveFrom: -1 }).session(session);

        if (!paymentMaster) {
          const error = new Error('No active payment master configuration found');
          error.status = 400;
          throw error;
        }

        if (!selectedPricing || !selectedPricing.isActive) {
          const error = new Error('Pricing record not found or inactive');
          error.status = 404;
          throw error;
        }

        const booking = new Booking({
          customerReference: customerId,
          bathroomCountReference: bathroomCountId || null,
          pricingReference: pricingId || null,
          serviceDurationReference: serviceDurationId || null,
          serviceFrequencyReference: serviceFrequencyId || null,
          subscriptionTypeReference: subscriptionTypeId || null,
          timeSlotReference: timeSlotId,
          scheduledDate: normalizedScheduledDate,
          startDateTime: calculatedStartDateTime,
          endDateTime: calculatedEndDateTime,
          paymentMethodReference: paymentMethodId || null,
          paymentAccountReference: paymentAccountId || null,
          transactionId: transactionId || '',
          amount: 0,
          createdBy: userId,
        });

        booking.$session(session);
        savedBooking = await booking.save();

        if (shouldCreateSubscription) {
          if (!userId) {
            const error = new Error('Authenticated user ID is required for a subscription booking');
            error.status = 400;
            throw error;
          }

          const subscription = new Subscription({
            bookingReference: savedBooking._id,
            customerReference: customerId,
            pricingReference: pricingId,
            serviceFrequencyReference: serviceFrequencyId,
            subscriptionTypeReference: subscriptionType._id,
            createdBy: userId,
            startDate: calculatedStartDateTime,
            endDate: subscriptionEndDate,
            totalVisits: normalizedTotalVisits,
            completedVisits: 0,
            remainingVisits: normalizedTotalVisits,
            scheduleIntervalDays,
            subscriptionStatus: 'Upcoming',
          });

          subscription.$session(session);
          savedSubscription = await subscription.save();

          const visits = visitScheduleDates.map((schedule, index) => ({
              subscriptionReference: savedSubscription._id,
              bookingReference: savedBooking._id,
              customerReference: customerId,
              timeSlotReference: timeSlotId,
              createdBy: userId,
              updatedBy: userId,
              visitNumber: index + 1,
              scheduledStartDateTime: schedule.scheduledStartDateTime,
              scheduledEndDateTime: schedule.scheduledEndDateTime,
            }));

          savedVisits = await Visit.insertMany(visits, { session, ordered: true });
        }

        const pricePerVisit = Number(selectedPricing.price);
        if (!Number.isFinite(pricePerVisit) || pricePerVisit < 0) {
          const error = new Error('Selected pricing record contains an invalid price');
          error.status = 400;
          throw error;
        }
        const baseAmount = roundCurrency(pricePerVisit * normalizedTotalVisits);
        const discountAmount = roundCurrency(baseAmount * Number(paymentMaster.discountRate) / 100);
        const taxableAmount = roundCurrency(baseAmount - discountAmount);
        const cgstAmount = roundCurrency(taxableAmount * Number(paymentMaster.cgstRate) / 100);
        const sgstAmount = roundCurrency(taxableAmount * Number(paymentMaster.sgstRate) / 100);
        const totalAmount = roundCurrency(taxableAmount + cgstAmount + sgstAmount);

        const servicePayment = new ServicePayment({
          bookingReference: savedBooking._id,
          subscriptionReference: savedSubscription?._id || null,
          customerReference: customerId,
          pricingReference: selectedPricing._id,
          paymentMasterReference: paymentMaster._id,
          paymentMethodReference: paymentMethodId || null,
          paymentAccountReference: paymentAccountId || null,
          createdBy: userId,
          pricePerVisit,
          totalServiceVisits: normalizedTotalVisits,
          baseAmount,
          cgstRate: paymentMaster.cgstRate,
          cgstAmount,
          sgstRate: paymentMaster.sgstRate,
          sgstAmount,
          discountRate: paymentMaster.discountRate,
          discountAmount,
          totalAmount,
          transactionId: transactionId || '',
        });
        servicePayment.$session(session);
        savedPayment = await servicePayment.save();

        savedBooking.amount = totalAmount;
        await savedBooking.save({ session });

        const dateKey = getDateKey(calculatedStartDateTime);
        const counter = await Counter.findByIdAndUpdate(
          `invoice-${dateKey}`,
          { $inc: { seq: 1 } },
          { new: true, upsert: true, setDefaultsOnInsert: true, session }
        );
        const invoice = new Invoice({
          invoiceNumber: `JHN${dateKey}-${String(counter.seq).padStart(4, '0')}`,
          customerReference: customerId,
          bookingReference: savedBooking._id,
          servicePaymentReference: savedPayment._id,
          amount: savedPayment.totalAmount,
          createdBy: userId,
        });
        invoice.$session(session);
        savedInvoice = await invoice.save();

        await ServicePaymentLog.create([{
          operation: 'CREATE',
          actionBy: userId,
          servicePaymentId: savedPayment._id,
          details: { action: 'Service payment calculated during booking creation' },
          previousValue: null,
          newValue: savedPayment.toObject(),
        }], { session });

        await BookingLog.insertMany([{
          operation: 'CREATE',
          actionBy: userId,
          bookingId: savedBooking._id,
          details: {
            action: shouldCreateSubscription
              ? 'Booking created, subscription, visits, service payment and invoice generated'
              : 'Booking created, service payment and invoice generated',
            invoiceNumber: savedInvoice?.invoiceNumber,
            amount: savedBooking.amount,
            servicePaymentId: savedPayment._id,
            subscriptionId: savedSubscription?.subscriptionId,
            totalVisits: savedVisits.length || undefined,
          },
          previousValue: null,
          newValue: savedBooking.toObject(),
        }], { session, ordered: true });
      });
    } finally {
      await session.endSession();
    }

    const populatedBooking = await populateBookingReferences(
      Booking.findById(savedBooking._id)
    );

    const response = {
      message: 'Booking created and invoice generated successfully',
      booking: populatedBooking,
    };

    if (savedInvoice) {
      response.invoice = savedInvoice;
    }

    if (savedSubscription) {
      response.subscription = savedSubscription;
      response.visits = savedVisits;
    }

    res.status(201).json(response);
  } catch (error) {
    if (error.code === 11000) {
      return res.status(409).json({
        message: 'A related booking record already exists',
      });
    }

    res.status(error.status || 500).json({
      message: error.message,
    });
  }
};

// Update the payment account on a booking and its linked service payment atomically.
exports.updateBookingPaymentAccount = async (req, res) => {
  const { id } = req.params;
  const { paymentAccountId } = req.body;

  if (!mongoose.Types.ObjectId.isValid(id)) {
    return res.status(400).json({ message: 'Invalid booking ID' });
  }

  if (!paymentAccountId) {
    return res.status(400).json({ message: 'paymentAccountId is required' });
  }

  if (!mongoose.Types.ObjectId.isValid(paymentAccountId)) {
    return res.status(400).json({ message: 'Invalid paymentAccountId' });
  }

  const userId = getUserObjectId(req);
  const session = await mongoose.startSession();
  let updatedBooking = null;

  try {
    await session.withTransaction(async () => {
      const booking = await Booking.findById(id).session(session);
      if (!booking) {
        const error = new Error('Booking not found');
        error.status = 404;
        throw error;
      }

      const paymentAccount = await PaymentAccount.findOne({
        _id: paymentAccountId,
        isActive: true,
      }).session(session);
      if (!paymentAccount) {
        const error = new Error('Active payment account not found');
        error.status = 404;
        throw error;
      }

      const servicePayment = await ServicePayment.findOne({
        bookingReference: booking._id,
      }).session(session);
      if (!servicePayment) {
        const error = new Error('Service payment not found for this booking');
        error.status = 404;
        throw error;
      }

      const previousBooking = booking.toObject();
      const previousServicePayment = servicePayment.toObject();

      booking.paymentAccountReference = paymentAccount._id;
      servicePayment.paymentAccountReference = paymentAccount._id;

      updatedBooking = await booking.save({ session });
      const updatedServicePayment = await servicePayment.save({ session });

      await BookingLog.create([{
        operation: 'UPDATE',
        actionBy: userId,
        bookingId: updatedBooking._id,
        details: { action: 'Booking payment account updated' },
        previousValue: previousBooking,
        newValue: updatedBooking.toObject(),
      }], { session });

      await ServicePaymentLog.create([{
        operation: 'UPDATE',
        actionBy: userId,
        servicePaymentId: updatedServicePayment._id,
        details: { action: 'Service payment account updated' },
        previousValue: previousServicePayment,
        newValue: updatedServicePayment.toObject(),
      }], { session });
    });
  } catch (error) {
    if (error.code === 11000) {
      return res.status(409).json({ message: 'A related payment record already exists' });
    }

    return res.status(error.status || 500).json({ message: error.message });
  } finally {
    await session.endSession();
  }

  try {
    const populatedBooking = await populateBookingReferences(
      Booking.findById(updatedBooking._id),
    );
    return res.status(200).json(populatedBooking);
  } catch (error) {
    return res.status(500).json({ message: error.message });
  }
};

// Update a booking
exports.updateBooking = async (req, res) => {
  try {
    if (!mongoose.Types.ObjectId.isValid(req.params.id)) {
      return res.status(400).json({
        message: 'Invalid booking ID',
      });
    }

    const previousBooking = await Booking.findById(req.params.id);

    if (!previousBooking) {
      return res.status(404).json({
        message: 'Booking not found',
      });
    }

    const {
      customerId,
      bathroomCountId,
      pricingId,
      serviceDurationId,
      serviceFrequencyId,
      subscriptionTypeId,
      timeSlotId,
      scheduledDate,
      startTime,
      paymentMethodId,
      receiverBankId,
      transactionId,
      amount,
    } = req.body;

    const updateData = {};

    if (customerId !== undefined) {
      updateData.customerReference = customerId;
    }

    if (bathroomCountId !== undefined) {
      updateData.bathroomCountReference = bathroomCountId || null;
    }

    if (pricingId !== undefined) {
      updateData.pricingReference = pricingId || null;
    }

    if (serviceDurationId !== undefined) {
      updateData.serviceDurationReference =
        serviceDurationId || null;
    }

    if (serviceFrequencyId !== undefined) {
      updateData.serviceFrequencyReference =
        serviceFrequencyId || null;
    }

    if (subscriptionTypeId !== undefined) {
      updateData.subscriptionTypeReference =
        subscriptionTypeId || null;
    }

    if (timeSlotId !== undefined) {
      updateData.timeSlotReference = timeSlotId;
    }

    if (paymentMethodId !== undefined) {
      updateData.paymentMethodReference =
        paymentMethodId || null;
    }

    if (receiverBankId !== undefined) {
      updateData.paymentAccountReference =
        receiverBankId || null;
    }

    if (transactionId !== undefined) {
      updateData.transactionId = transactionId;
    }

    if (amount !== undefined) {
      const normalizedAmount = Number(amount);

      if (
        Number.isNaN(normalizedAmount) ||
        normalizedAmount < 0
      ) {
        return res.status(400).json({
          message:
            'amount must be a valid non-negative number',
        });
      }

      updateData.amount = normalizedAmount;
    }

    const shouldRecalculateTime =
      scheduledDate !== undefined ||
      startTime !== undefined ||
      timeSlotId !== undefined ||
      serviceDurationId !== undefined ||
      pricingId !== undefined;

    if (shouldRecalculateTime) {
      const resolvedTimeSlotId =
        timeSlotId || previousBooking.timeSlotReference;

      const resolvedServiceDurationId =
        serviceDurationId !== undefined
          ? serviceDurationId
          : previousBooking.serviceDurationReference;

      const resolvedPricingId =
        pricingId !== undefined
          ? pricingId
          : previousBooking.pricingReference;

      const resolvedScheduledDate = scheduledDate
        ? String(scheduledDate)
        : previousBooking.scheduledDate
          .toISOString()
          .slice(0, 10);

      if (
        !mongoose.Types.ObjectId.isValid(resolvedTimeSlotId)
      ) {
        return res.status(400).json({
          message: 'Invalid timeSlotId',
        });
      }

      if (
        !/^\d{4}-\d{2}-\d{2}$/.test(resolvedScheduledDate)
      ) {
        return res.status(400).json({
          message:
            'scheduledDate must use YYYY-MM-DD format',
        });
      }

      const selectedTimeSlot = await TimeSlot.findById(
        resolvedTimeSlotId
      );

      if (!selectedTimeSlot) {
        return res.status(404).json({
          message: 'Selected time slot not found',
        });
      }

      const slotStartMinutes = parseTimeToMinutes(
        startTime || selectedTimeSlot.startTime
      );

      if (slotStartMinutes === null) {
        return res.status(400).json({
          message:
            'Selected time slot contains an invalid startTime',
        });
      }

      let resolvedServiceDuration = null;

      if (resolvedServiceDurationId) {
        const serviceDuration =
          await ServiceDuration.findById(
            resolvedServiceDurationId
          );

        if (serviceDuration) {
          resolvedServiceDuration = Number(
            serviceDuration.durationMinutes
          );
        }
      }

      if (!resolvedServiceDuration && resolvedPricingId) {
        const pricing = await Pricing.findById(
          resolvedPricingId
        ).populate('serviceDurationReference');

        if (
          pricing &&
          pricing.serviceDurationReference &&
          pricing.serviceDurationReference.durationMinutes !==
            undefined
        ) {
          resolvedServiceDuration = Number(
            pricing.serviceDurationReference.durationMinutes
          );
        }
      }

      if (
        !resolvedServiceDuration ||
        resolvedServiceDuration <= 0
      ) {
        return res.status(400).json({
          message:
            'Unable to determine service duration from serviceDurationId or pricingId',
        });
      }

      const bufferTime =
        Number(selectedTimeSlot.bufferTime) || 0;

      const totalDuration =
        resolvedServiceDuration + bufferTime;

      const calculatedStartDateTime =
        combineDateAndTime(
          resolvedScheduledDate,
          slotStartMinutes
        );

      const calculatedEndDateTime =
        combineDateAndTime(
          resolvedScheduledDate,
          slotStartMinutes + totalDuration
        );

      if (
        !calculatedStartDateTime ||
        !calculatedEndDateTime
      ) {
        return res.status(400).json({
          message:
            'Unable to calculate booking startDateTime and endDateTime',
        });
      }

      const existingBookings = await Booking.find({
        _id: {
          $ne: previousBooking._id,
        },
        startDateTime: {
          $lt: calculatedEndDateTime,
        },
        endDateTime: {
          $gt: calculatedStartDateTime,
        },
      });

      const conflictingBooking = existingBookings.find(
        (existingBooking) => {
          return !existingBooking.isCancelled;
        }
      );

      if (conflictingBooking) {
        return res.status(409).json({
          message:
            'The selected date and time slot is already booked. Please choose another slot.',
        });
      }

      updateData.timeSlotReference = resolvedTimeSlotId;
      updateData.scheduledDate = new Date(
        `${resolvedScheduledDate}T00:00:00.000Z`
      );
      updateData.startDateTime =
        calculatedStartDateTime;
      updateData.endDateTime = calculatedEndDateTime;
    }

    const updatedBooking = await Booking.findByIdAndUpdate(
      req.params.id,
      updateData,
      {
        new: true,
        runValidators: true,
      }
    );

    const userId = getUserObjectId(req);

    await BookingLog.create({
      operation: 'UPDATE',
      actionBy: userId,
      bookingId: updatedBooking._id,
      details: {
        updatedFields: Object.keys(updateData),
      },
      previousValue: previousBooking.toObject(),
      newValue: updatedBooking.toObject(),
    });

    const populatedBooking = await populateBookingReferences(
      Booking.findById(updatedBooking._id)
    );

    res.status(200).json(populatedBooking);
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

// Delete a booking and associated invoice
exports.deleteBooking = async (req, res) => {
  try {
    if (!mongoose.Types.ObjectId.isValid(req.params.id)) {
      return res.status(400).json({
        message: 'Invalid booking ID',
      });
    }

    const booking = await Booking.findByIdAndDelete(
      req.params.id
    );

    if (!booking) {
      return res.status(404).json({
        message: 'Booking not found',
      });
    }

    await Invoice.findOneAndDelete({
      bookingId: booking._id,
    });

    const userId = getUserObjectId(req);

    await BookingLog.create({
      operation: 'DELETE',
      actionBy: userId,
      bookingId: booking._id,
      details: {
        action:
          'Booking and associated invoice deleted',
      },
      previousValue: booking.toObject(),
      newValue: null,
    });

    res.status(200).json({
      message:
        'Booking and associated invoice deleted successfully',
    });
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

const updateBookingStatus = async (req, res, statusName, extraFields = {}) => {
  try {
    const normalizedStatus = statusName.toLowerCase();
    const lifecycleFields = normalizedStatus === 'cancelled'
      ? { isPending: false, isCompleted: false, isCancelled: true, isActive: false }
      : normalizedStatus === 'completed'
        ? { isPending: false, isCompleted: true, isCancelled: false, isActive: true }
        : { isPending: true, isCompleted: false, isCancelled: false, isActive: true };

    const booking = await Booking.findByIdAndUpdate(
      req.params.id,
      { ...lifecycleFields, ...extraFields },
      { new: true, runValidators: true },
    );
    if (!booking) {
      if (normalizedStatus === 'completed') {
        const visit = await Visit.findByIdAndUpdate(
          req.params.id,
          {
            isPending: false,
            isCompleted: true,
            isCancelled: false,
            actualEndDateTime: new Date(),
          },
          { new: true, runValidators: true },
        );

        if (visit) {
          return res.status(200).json(visit);
        }
      }

      return res.status(404).json({ message: 'Booking not found' });
    }

    await Subscription.findOneAndUpdate(
      { bookingReference: booking._id },
      {
        ...lifecycleFields,
        subscriptionStatus: statusName === 'Scheduled' ? 'Upcoming' : statusName,
      },
      { runValidators: true },
    );

    const userId = getUserObjectId(req);
    await BookingLog.create({
      operation: 'UPDATE',
      actionBy: userId,
      bookingId: booking._id,
      details: { action: `Booking marked ${statusName}` },
      previousValue: null,
      newValue: booking.toObject(),
    });

    const populatedBooking = await populateBookingReferences(
      Booking.findById(booking._id),
    );
    res.status(200).json(populatedBooking);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.cancelBooking = (req, res) => updateBookingStatus(req, res, 'Cancelled');
exports.restoreBooking = (req, res) => updateBookingStatus(req, res, 'Scheduled');
exports.completeBooking = (req, res) =>
  updateBookingStatus(req, res, 'Completed', {
    completionPhoto: req.body.completionPhoto || null,
  });
